﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS2020513B
{
    public partial class Form1 : Form
    {
        Random RN = new Random();
        int NUM;
        int SeqNo = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NUM = RN.Next(0, 10);
            this.Text += NUM + " , ";
            guess.Text = null;
            PGB.Value = 30;
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (PGB.Value == 0)
            {
                timer1.Enabled = false;
                MessageBox.Show("Game Over!", "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                PGB.PerformStep();
                Counter.Text = PGB.Value.ToString();
            }                     
        }        

        private void guess_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(guess.Text,out int result)&&result==NUM)
            {
                timer1.Enabled = false;
                MessageBox.Show("猜對了!", "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        pictureBox1.Image = Resource1._1_秋色;
                        break;
                    case 1:
                        pictureBox1.Image = Resource1._2_日落;
                        break;
                    case 2:
                        pictureBox1.Image = Resource1._3_微軟;
                        break;
                    case 3:
                        pictureBox1.Image = Resource1._4_夕陽;
                        break;
                    case 4:
                        pictureBox1.Image = Resource1._5_沙漠;
                        break;
                }

            }
            catch(Exception EX)
            {
                MessageBox.Show(EX.ToString(), "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer2.Enabled = !timer2.Enabled;
            if(timer2.Enabled) button2.Text = "暫停";
            else button2.Text = "自動輪播";

           // if (button2.Text == "倫播On/Off"|| button2.Text == "自動輪播")
           // {
           //     button2.Text = "暫停";
           //     timer2.Enabled = true;
           // }
           //else
           // {
           //     button2.Text = "自動輪播";
           //     timer2.Enabled = false;
           // }            
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            comboBox1.Text = comboBox1.Items[SeqNo].ToString();
            if (SeqNo == 4) SeqNo = 0;
            else SeqNo++;
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            pictureBox1.Width = vScrollBar1.Value;
            pictureBox1.Height = vScrollBar1.Value;
            this.Text = "圖像(正方形邊長) :" +vScrollBar1.Value.ToString() + "(pixels)";
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            timer2.Interval = hScrollBar1.Value;
            this.Text = "圖像間隔顯示數度 :" + Math.Round((decimal)hScrollBar1.Value/1000,3).ToString() + "秒";
        }
    }
}
