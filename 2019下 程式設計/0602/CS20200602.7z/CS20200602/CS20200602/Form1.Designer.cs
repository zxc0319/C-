﻿namespace CS20200602
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.TDR = new System.Windows.Forms.TextBox();
            this.TD2 = new System.Windows.Forms.TextBox();
            this.TD1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Result = new System.Windows.Forms.TextBox();
            this.TB2 = new System.Windows.Forms.TextBox();
            this.TB1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TDR
            // 
            this.TDR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TDR.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TDR.Location = new System.Drawing.Point(600, 85);
            this.TDR.MaxLength = 12;
            this.TDR.Name = "TDR";
            this.TDR.ReadOnly = true;
            this.TDR.Size = new System.Drawing.Size(167, 29);
            this.TDR.TabIndex = 73;
            this.TDR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TD2
            // 
            this.TD2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TD2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TD2.Location = new System.Drawing.Point(357, 85);
            this.TD2.MaxLength = 12;
            this.TD2.Name = "TD2";
            this.TD2.ReadOnly = true;
            this.TD2.Size = new System.Drawing.Size(140, 29);
            this.TD2.TabIndex = 72;
            this.TD2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TD1
            // 
            this.TD1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TD1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TD1.Location = new System.Drawing.Point(22, 85);
            this.TD1.MaxLength = 12;
            this.TD1.Name = "TD1";
            this.TD1.ReadOnly = true;
            this.TD1.Size = new System.Drawing.Size(140, 29);
            this.TD1.TabIndex = 71;
            this.TD1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.Aqua;
            this.comboBox1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "<<(Shift Left)",
            ">>(Shift Right)",
            "~(1\'s Complement)",
            "&(AND)",
            "∣(OR)",
            "^(XOR)",
            "Exchange",
            "-(2\'s Complement)"});
            this.comboBox1.Location = new System.Drawing.Point(181, 25);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(156, 29);
            this.comboBox1.TabIndex = 70;
            this.comboBox1.Text = "請選擇";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Result
            // 
            this.Result.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Result.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Result.ForeColor = System.Drawing.Color.Red;
            this.Result.Location = new System.Drawing.Point(600, 25);
            this.Result.MaxLength = 25;
            this.Result.Name = "Result";
            this.Result.ReadOnly = true;
            this.Result.Size = new System.Drawing.Size(167, 29);
            this.Result.TabIndex = 69;
            this.Result.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Result.TextChanged += new System.EventHandler(this.TB1_TextChanged);
            // 
            // TB2
            // 
            this.TB2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TB2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB2.Location = new System.Drawing.Point(357, 25);
            this.TB2.MaxLength = 12;
            this.TB2.Name = "TB2";
            this.TB2.Size = new System.Drawing.Size(140, 29);
            this.TB2.TabIndex = 68;
            this.TB2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TB2.TextChanged += new System.EventHandler(this.TB1_TextChanged);
            // 
            // TB1
            // 
            this.TB1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TB1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB1.Location = new System.Drawing.Point(22, 25);
            this.TB1.MaxLength = 12;
            this.TB1.Name = "TB1";
            this.TB1.Size = new System.Drawing.Size(140, 29);
            this.TB1.TabIndex = 67;
            this.TB1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TB1.TextChanged += new System.EventHandler(this.TB1_TextChanged);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.Fuchsia;
            this.label1.Location = new System.Drawing.Point(527, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 38);
            this.label1.TabIndex = 66;
            this.label1.Text = "=";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 228);
            this.Controls.Add(this.TDR);
            this.Controls.Add(this.TD2);
            this.Controls.Add(this.TD1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.TB2);
            this.Controls.Add(this.TB1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Bitwise Operations";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TDR;
        private System.Windows.Forms.TextBox TD2;
        private System.Windows.Forms.TextBox TD1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox Result;
        private System.Windows.Forms.TextBox TB2;
        private System.Windows.Forms.TextBox TB1;
        private System.Windows.Forms.Label label1;
    }
}

