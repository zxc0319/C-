﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS20200602
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TB1_TextChanged(object sender, EventArgs e)
        {
            try
            {

                checked
                {
                    //1.TB1

                    //byte TB = byte.Parse(TB1.Text);
                    //TD1.Clear();
                    //for (byte i = 0; i <= 7; i++)
                    //{
                    //    TD1.Text = (TB % 2).ToString() + TD1.Text;
                    //    //TB = (byte)(TB / 2);
                    //    TB = (byte)(TB >> 1);
                    //}

                    //2.
                    byte TB = 0;
                    if (((TextBox)sender).Name == "TB1")
                    {
                        TB = byte.Parse(TB1.Text);
                    }
                    else if (((TextBox)sender).Name == "TB2")
                    {
                        TB = byte.Parse(TB2.Text);
                    }
                    else if (((TextBox)sender).Name == "Result")
                    {
                        TB = byte.Parse(Result.Text);
                    }

                    string TD = null;
                    for (byte i = 0; i <= 7; i++)
                    {
                        TD= (TB % 2).ToString() + TD;
                        //TB = (byte)(TB / 2);
                        TB = (byte)(TB >> 1);
                    }

                    switch (((TextBox)sender).Name)
                    {
                        case "TB1":
                            TD1.Text = TD;
                            break;
                        case "TB2":
                            TD2.Text = TD;
                            break;
                        case "Result":
                            TDR.Text = TD;
                            break;
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                checked
                {
                    switch (comboBox1.SelectedIndex)
                    {
                        case 0:
                            Result.Text = (byte.Parse(TB1.Text) << byte.Parse(TB2.Text)).ToString();
                            break;
                        case 1:
                            Result.Text = (byte.Parse(TB1.Text) >> byte.Parse(TB2.Text)).ToString();
                            break;
                        case 2:
                            TDR.Clear();
                            for (int i = 0; i < TD1.Text.Length; i++)
                            {
                                if (TD1.Text.Substring(i, 1) == "0") TDR.Text += "1";
                                else TDR.Text += "0";
                            }
                            break;
                        case 3:
                            Result.Text = (byte.Parse(TB1.Text) % byte.Parse(TB2.Text)).ToString();
                            break;
                        case 4:
                            Result.Text = (byte.Parse(TB1.Text) | byte.Parse(TB2.Text)).ToString();
                            break;
                        case 5:
                            Result.Text = (byte.Parse(TB1.Text) ^ byte.Parse(TB2.Text)).ToString();
                            break;
                        case 6:
                            TB1.Text = (byte.Parse(TB1.Text) ^ byte.Parse(TB2.Text)).ToString();
                            TB2.Text = (byte.Parse(TB1.Text) ^ byte.Parse(TB2.Text)).ToString();
                            TB1.Text = (byte.Parse(TB1.Text) ^ byte.Parse(TB2.Text)).ToString();
                            break;
                        case 7:
                            break;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {

            }           
                
        }
    }
}
