﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20200526_Shell
{
    class Recursionfunctions
    {
        public double RFact(ulong n)
        {
            checked
            {
                if (n == 0 || n == 1) return 1;
                else return n * RFact(n - 1);
                
            }
        }
        public double RFib(ulong n)
        {
            checked
            {
                if (n == 0) return 0;
                else if (n == 1) return 1;
                else return RFib(n - 1) + RFib(n - 2);               
            }
        }
        public decimal gcd(decimal a, decimal b)
        {
            //if (0 != b)
            //{
            //     while (0 != (a %= b) && 0 != (b %= a)) ;
            //}              
            //return a + b;

            if (a >= b)
            {
                if (a % b == 0) { return b; }
                else { return gcd(b, a % b); }
            }
            else
            {
                if (b % a == 0) { return a; }
                else { return gcd(a, b % a); }

            }
        }
        public decimal lcm(decimal a, decimal b)
        {
            return a * b / gcd(a, b);
        }
    }
}
