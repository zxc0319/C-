﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CS20200526_Shell
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random RN = new Random();
        Recursionfunctions RF = new Recursionfunctions();
        private void Number_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && !char.IsDigit(e.KeyChar))
            {
                this.Text = e.KeyChar.ToString();
                e.Handled = true;
            }
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Display.Clear();
            double Starttime = System.DateTime.Now.TimeOfDay.TotalMilliseconds;
            try
            {
                switch (comboBox1.SelectedIndex)
                {
                    case 0:  //Factorial  
                        for (byte i = 0; i <= byte.Parse(Number.Text); i++)
                        {
                            //Display.Text += i + "!= " + Factorial(i) + Environment.NewLine;
                            Display.Text += i + "!= " + RF.RFact(i) +"\r\n";
                        }
                        break;

                    case 1:  //Fibonacci Number                        
                        for (byte i = 0; i <= byte.Parse(Number.Text); i++)
                        {
                            //Display.Text += "Fibonacci(" + i + ")= " + FIB(i) + Environment.NewLine;
                            Display.Text += "Fibonacci(" + i + ")= " + RF.RFib(i) + "\r\n";
                        }
                        break;

                    case 2:
                        decimal n1 = decimal.Parse(N1.Text);
                        decimal n2 = decimal.Parse(N2.Text);
                        //GCDValue.Text = GCD(n1, n2).ToString();
                        //LCMValue.Text = LCM(n1, n2).ToString();
                        GCDValue.Text = RF.gcd(n1, n2).ToString();
                        LCMValue.Text = RF.lcm(n1, n2).ToString();
                        break;

                    case 3:
                        int[] N = new int[100000];
                        Random RN = new Random();
                        string show = null;

                        for (int i = 0; i < int.Parse(Number.Text); i++)
                        {
                            N[i] = RN.Next(0, 1000);
                            show += N[i] + ", ";
                        }
                        show += Environment.NewLine;
                        Display.Text = show + Environment.NewLine
                                       + "====================Sorted=====================" + Environment.NewLine + Environment.NewLine;
                        //Bubble Sort
                        int temp;
                        for (int i = 1; i < int.Parse(Number.Text); i++)
                        {
                            for (int j = 0; j < int.Parse(Number.Text) - i; j++)
                            {
                                if (N[j] > N[j + 1])
                                {
                                    temp = N[j];
                                    N[j] = N[j + 1];
                                    N[j + 1] = temp;
                                }
                            }
                        }
                        //QuickSort
                        //https://dotblogs.com.tw/kennyshu/2009/10/24/11270
                        show = null;                        
                        for (int i = 0; i < int.Parse(Number.Text); i++)
                        {
                            show += N[i] + ", ";
                        }
                        Display.Text += show;
                        break;

                    case 4:
                        steps = 0;
                        int disks = int.Parse(Number.Text);
                        HanoiTower(disks, "Rod[A]", "Rod[C]", "Rod[B]");
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                double FinishTime = DateTime.Now.TimeOfDay.TotalMilliseconds;
                this.Text = Math.Round(FinishTime - Starttime, 2) + " 毫秒[10^(-3)]";
            }
        }
        int steps;

        public void HanoiTower(int N, string Source, string Destination, string Via)
        {
            if (N == 0) return;
            else if (N == 1)
            {
                steps++;
                Display.Text += steps + ". Move Disk " + N + " From " + Source + " To " + Destination + "\r\n";
            }
            else
            {
                HanoiTower(N - 1, Source, Via, Destination);  // HanoiTower(N-1, "Rod[A]", "Rod[B]", "Rod[C]");
                steps++;
                Display.Text += steps + ". Move Disk " + N + " From " + Source + " To " + Destination + "\r\n";
                HanoiTower(N - 1, Via, Destination, Source); // HanoiTower(N - 1, "Rod[C]", "Rod[A]", "Rod[B]");
            }            
        }
        public decimal Factorial(byte N)
        {
            checked
            {
                if (N == 0) return 1;
                else
                {
                    decimal Result = 1;
                    for (byte i = 1; i <= N; i++)
                    {
                        Result *= i;
                    }
                    return Result;
                }
            }
        }
        
        public decimal FIB(ulong N)
        {
            checked
            {
                if (N == 0) return 0;
                else if (N == 1) return 1;
                else
                {
                    decimal F0 = 0;
                    decimal F1 = 1;
                    decimal Sum;
                    ulong i = 2;
                    while (i <= N)
                    {
                        Sum = F0 + F1;
                        F0 = F1;
                        F1 = Sum;
                        i++;
                    }
                    return F1;
                }
            }
        }
        
        public decimal GCD(decimal A, decimal B)
        {
            checked
            {
                decimal temp, R;
                if (A < 0) A = -A;
                if (B < 0) B = -B;
                if (A < B)
                {
                    temp = A;
                    A = B;
                    B = temp;
                }
                while (true)
                {
                    R = A % B;
                    if (R == 0) return B;
                    A = B;
                    B = R;
                }
            }
        }
        
        public decimal LCM(decimal A, decimal B)
        {
            checked
            {
                decimal Product = A * B;
                return Product / GCD(A, B);
            }
        }             
                
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //MessageBox.Show("Say Bye Bye Again!!", "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dr = MessageBox.Show("確定是否關閉視窗?", "提示訊息", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            switch (dr)
            {
                case System.Windows.Forms.DialogResult.Yes: e.Cancel = false; break;
                case System.Windows.Forms.DialogResult.No: e.Cancel = true; break;
            }
        }
        // Problem-Solve
        // 1: Forwarding
        // 2: Backwarding
        // HanoiTower(4,"A","C","B")
        // HanoiTower(3,"A","B","C")
        // Move 4 from A to C
        // HanoiTower(3,"B","C","A")


    }
}
