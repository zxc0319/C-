﻿namespace CS20200324B
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Display = new System.Windows.Forms.TextBox();
            this.Nth = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.swich = new System.Windows.Forms.Button();
            this.SC = new System.Windows.Forms.Button();
            this.DisplayA = new System.Windows.Forms.TextBox();
            this.DisplayB = new System.Windows.Forms.TextBox();
            this.SleepTime = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // Display
            // 
            this.Display.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Display.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Display.ForeColor = System.Drawing.Color.Blue;
            this.Display.Location = new System.Drawing.Point(310, 23);
            this.Display.Name = "Display";
            this.Display.ReadOnly = true;
            this.Display.Size = new System.Drawing.Size(367, 36);
            this.Display.TabIndex = 0;
            this.Display.Text = "資管一乙";
            this.Display.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Display.TextChanged += new System.EventHandler(this.Display_TextChanged);
            this.Display.DoubleClick += new System.EventHandler(this.Display_DoubleClick);
            this.Display.MouseEnter += new System.EventHandler(this.Display_MouseEnter);
            this.Display.MouseLeave += new System.EventHandler(this.Display_MouseLeave);
            // 
            // Nth
            // 
            this.Nth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Nth.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Nth.ForeColor = System.Drawing.Color.Red;
            this.Nth.Location = new System.Drawing.Point(439, 113);
            this.Nth.MaxLength = 3;
            this.Nth.Name = "Nth";
            this.Nth.Size = new System.Drawing.Size(101, 29);
            this.Nth.TabIndex = 2;
            this.Nth.Text = "5";
            this.Nth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.toolTip1.SetToolTip(this.Nth, "接棒人數");
            this.Nth.TextChanged += new System.EventHandler(this.Nth_TextChanged);
            this.Nth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Nth_KeyPress);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // swich
            // 
            this.swich.BackColor = System.Drawing.Color.Lime;
            this.swich.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.swich.Location = new System.Drawing.Point(734, 23);
            this.swich.Name = "swich";
            this.swich.Size = new System.Drawing.Size(140, 35);
            this.swich.TabIndex = 3;
            this.swich.Text = "ON/OFF";
            this.toolTip1.SetToolTip(this.swich, "時間開關");
            this.swich.UseVisualStyleBackColor = false;
            this.swich.Click += new System.EventHandler(this.button1_Click);
            // 
            // SC
            // 
            this.SC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.SC.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SC.Location = new System.Drawing.Point(59, 24);
            this.SC.Name = "SC";
            this.SC.Size = new System.Drawing.Size(140, 35);
            this.SC.TabIndex = 4;
            this.SC.Text = "Start/Cancel";
            this.toolTip1.SetToolTip(this.SC, "啟動/取消按鍵");
            this.SC.UseVisualStyleBackColor = false;
            this.SC.Click += new System.EventHandler(this.SC_Click);
            // 
            // DisplayA
            // 
            this.DisplayA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.DisplayA.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.DisplayA.Location = new System.Drawing.Point(59, 94);
            this.DisplayA.Multiline = true;
            this.DisplayA.Name = "DisplayA";
            this.DisplayA.ReadOnly = true;
            this.DisplayA.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DisplayA.Size = new System.Drawing.Size(294, 408);
            this.DisplayA.TabIndex = 5;
            this.toolTip1.SetToolTip(this.DisplayA, "甲班接力結果");
            this.DisplayA.TextChanged += new System.EventHandler(this.DisplayA_TextChanged);
            // 
            // DisplayB
            // 
            this.DisplayB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.DisplayB.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.DisplayB.Location = new System.Drawing.Point(635, 94);
            this.DisplayB.Multiline = true;
            this.DisplayB.Name = "DisplayB";
            this.DisplayB.ReadOnly = true;
            this.DisplayB.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.DisplayB.Size = new System.Drawing.Size(294, 408);
            this.DisplayB.TabIndex = 6;
            this.toolTip1.SetToolTip(this.DisplayB, "乙班接力結果");
            this.DisplayB.TextChanged += new System.EventHandler(this.DisplayB_TextChanged);
            // 
            // SleepTime
            // 
            this.SleepTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.SleepTime.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SleepTime.ForeColor = System.Drawing.Color.Blue;
            this.SleepTime.Location = new System.Drawing.Point(439, 189);
            this.SleepTime.MaxLength = 4;
            this.SleepTime.Name = "SleepTime";
            this.SleepTime.Size = new System.Drawing.Size(101, 29);
            this.SleepTime.TabIndex = 7;
            this.SleepTime.Text = "3000";
            this.SleepTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.toolTip1.SetToolTip(this.SleepTime, "Max. Sleep Time");
            this.SleepTime.TextChanged += new System.EventHandler(this.SleepTime_TextChanged);
            this.SleepTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Nth_KeyPress);
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 200;
            this.toolTip1.AutoPopDelay = 9000;
            this.toolTip1.InitialDelay = 200;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 40;
            this.toolTip1.ShowAlways = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(986, 553);
            this.Controls.Add(this.Display);
            this.Controls.Add(this.SleepTime);
            this.Controls.Add(this.DisplayB);
            this.Controls.Add(this.DisplayA);
            this.Controls.Add(this.SC);
            this.Controls.Add(this.swich);
            this.Controls.Add(this.Nth);
            this.Name = "Form1";
            this.Text = "資管甲乙班";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.DoubleClick += new System.EventHandler(this.Form1_DoubleClick);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Display;
        private System.Windows.Forms.TextBox Nth;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button swich;
        private System.Windows.Forms.Button SC;
        private System.Windows.Forms.TextBox DisplayA;
        private System.Windows.Forms.TextBox DisplayB;
        private System.Windows.Forms.TextBox SleepTime;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

