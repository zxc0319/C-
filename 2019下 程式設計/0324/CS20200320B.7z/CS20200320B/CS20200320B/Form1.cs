﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS20200320B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Display_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Display.Text = DateTime.Now.ToString();

        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            Display.Text = DateTime.Now.ToString();
            
        }

        private void Display_DoubleClick(object sender, EventArgs e)
        {
            Display.Text = DateTime.Now.ToString();
        }

        private void Display_MouseEnter(object sender, EventArgs e)
        {
            Display.Text = DateTime.Now.ToString();
        }

        private void Display_MouseLeave(object sender, EventArgs e)
        {
            Display.Text = "資管一乙";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Display.Text = DateTime.Now.ToString();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = !timer1.Enabled;
            if (timer1.Enabled)
            {
                swich.Text = "OFF";
                swich.BackColor = Color.Green;
            }
            else 
            {
                swich.Text = "ON";
                swich.BackColor = Color.Red;
            }
        }

        private void Nth_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar)&& e.KeyChar!=8)
            {
                this.Text = e.KeyChar.ToString();
                e.Handled = true;
            }
            
            
        }

        private void Nth_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(Nth.Text, out int result)) Nth.Text = "5";
        }

        private void SleepTime_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(SleepTime.Text, out int result)) SleepTime.Text = "3000";
        }
    }
}
