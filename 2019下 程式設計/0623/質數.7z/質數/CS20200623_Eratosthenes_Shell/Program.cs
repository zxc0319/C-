﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20200623_Eratosthenes_Shell
{
    class Program
    {//uint：0 至 4,294,967,295
        //ulong	0 至 18,446,744,073,709,551,615       
        static int EN, Eptr, EP;   //for test variables in Class
        
        static void Main(string[] args)
        {
           Eratosthenes PN = new Eratosthenes();
            PN.Create();
            while (true)
            {
                try
                {
                    checked
                    {
                        //Test1(PrimeYesNo)：2147483646 ~ 2147000000.....共計 22450 個質數：8.4秒(int)
                        //Test2(Eratosthenes)：2147483646 ~ 2147000000...共計 22450 個質數：4.8秒(int)
                        //Test1(PrimeYesNo)：2147483646 ~ 2147000000.....共計 22450 個質數：41.04秒(uint)
                        //Test2(Eratosthenes)：2147483646 ~ 2147000000...共計 22450 個質數：7.6秒(uint)

                        Console.WriteLine("Prime Number？？(Between two Number)2147483646 2146480000");
                        string[] Line = Console.ReadLine().Split(' ');
                        if (Line[0] == "") break;
                        int X = int.Parse(Line[0]);
                        int Y = int.Parse(Line[1]);
                        int temp;
                        if (X > Y) { temp = X; X = Y; Y = temp; }

                        //Flowchart of prime number：http://www.rff.com/prime-numbers.htm
                        //Eratosthenes：https://en.wikipedia.org/wiki/Eratosthenes
                        //埃拉托斯特尼篩法：https://zh.wikipedia.org/wiki/埃拉托斯特尼篩法                        
                        //質數列表：https://zh.wikipedia.org/wiki/質數列表                        
                        //前1000個質數：https://miniwebtool.com/zh-tw/first-n-prime-numbers/?number=1000

                        uint no = 0;   //number of prime number                        
                        string result = null;
                        double Start = DateTime.Now.TimeOfDay.TotalSeconds;
                        for (int i = X; i <= Y; i++)  //i <= 2147483646
                        {
                            //if (PrimeYesNo(i))
                            if (PN.Test(i))
                            {
                                no++;
                                //Console.WriteLine("P" + no + "= " + i);
                                result += "P[" + no + "]= " + i + "\n";
                                
                            }
                        }
                        Console.WriteLine(result);
                        double Finish = DateTime.Now.TimeOfDay.TotalSeconds;
                        Console.WriteLine("\n共計 " + no + " 個質數：" + Math.Round(Finish - Start, 3) + "秒");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                    //Console.WriteLine(EN + " " + Eptr + " " + EP );
                }
                finally
                {
                    Console.WriteLine("Press any key to Exit");
                }
            }
        }
       
        static bool PrimeYesNo(int N)
        {
            //2.Performance
            if (N <= 1) return false;
            else if (N == 2) return true;
            else if (N % 2 == 0) return false;
            else
            {
                //for (decimal i = 3; i < N; i = i+2)
                //for (int i = 3; i <= (int)Math.Pow((double)N,1.0/2.0)+1; i += 2)   // 32.2秒
                for (int i = 3; i <= Math.Sqrt(N) + 1; i += 2)                       // 8.9秒
                {
                    if (N % i == 0) return false;
                }
                return true;
            }
        }        
    }


    class Eratosthenes
    {
        public int[] PrimeNo = new int[1000001];
        public void Create()
        {
            Console.WriteLine("\n\n" + System.DateTime.Now);
            PrimeNo[1] = 2;
            PrimeNo[2] = 3;
            PrimeNo[3] = 5;
            PrimeNo[4] = 7;
            int NN = 11;
            int np;
            for (int n = 5; n <= 100000; n++)
            {
                np = 1;
                while (Math.Sqrt(NN) + 1 > PrimeNo[np])
                {
                    if (NN % PrimeNo[np] == 0)
                    {
                        NN ++;
                        np = 1;
                    }
                    else np++;
                }
                PrimeNo[n] = NN;
                NN++;
            }
            Console.WriteLine("PrimeNo[1000]=" + PrimeNo[1000]);
            Console.WriteLine("PrimeNo[10000]=" + PrimeNo[100000]);
            Console.WriteLine("(int)PrimeNo[10000]^2=" + PrimeNo[100000]* PrimeNo[100000]);
            Console.WriteLine("(uint)PrimeNo[10000]^2=" + (uint)PrimeNo[100000] * (uint)PrimeNo[100000]);
            Console.WriteLine("(long)PrimeNo[10000]^2=" + (long)PrimeNo[100000] * (long)PrimeNo[100000]);
            Console.WriteLine("(double)PrimeNo[10000]^2=" + (double)PrimeNo[100000] * (double)PrimeNo[100000]);
            Console.WriteLine("\n\n" + System.DateTime.Now);

        }
        public bool Test(int N)
        {
            int ptr = 1;
            if (N <= 1) return false;
            else if (N == 2) return true;            
            else if (N % 2 == 0) return false;           
            else
            {
                while (N >= (long)PrimeNo[ptr] * (long)PrimeNo[ptr] )
                {
                    if (N % PrimeNo[ptr] == 0) return false;
                    else ptr++;
                }
                return true;
                //for (decimal i = 3; i < N; i = i+2)
                //for (int i = 3; i <= (int)Math.Pow((double)N,1.0/2.0)+1; i += 2)   // 32.2秒
                //for (int i = 1; i <= Math.Sqrt(N) + 1; i++)
                //{
                //    if (N % PrimeNo[i] == 0) return false;
                //}
                //return true;
            }                      
        }
    }
}
