﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20200526_Shell
{
    class Recursionfunctions
    {
        public double RFact(ulong n)
        {
            checked
            {
                if (n == 0 || n == 1) return 1;
                else return n * RFact(n - 1);
                
            }
        }
        public double RFib(ulong n)
        {
            checked
            {
                if (n == 0) return 0;
                else if (n == 1) return 1;
                else return RFib(n - 1) + RFib(n - 2);               
            }
        }
    }
}
