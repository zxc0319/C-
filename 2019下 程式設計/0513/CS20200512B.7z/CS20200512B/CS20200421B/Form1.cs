﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Office = Microsoft.Office.Interop;

namespace CS20200421B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random RN = new Random();       
        STUDENT[] ST = new STUDENT[100000];
        struct STUDENT
        {
            public string Name;
            public int Bcc;
            public int Database;
            public int CSharp;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string Result;
                string Line;
                int Total;
                switch (ComboBox1.SelectedIndex)
                {
                    case 0:
                        Display.Clear();
                        Result = null;
                        for(int i =0;i<NUD.Value;i++)
                        {
                            int NameLength;
                            ST[i].Name = ((char)RN.Next(65, 91)).ToString();                             
                            NameLength = RN.Next(3, 8);
                            for (int j = 1; j <= NameLength; j++)
                            {
                                ST[i].Name += ((char)RN.Next(97, 123)).ToString();
                            }
                            ST[i].Bcc = RN.Next(0, 101);
                            ST[i].Database = RN.Next(0, 101);
                            ST[i].CSharp = RN.Next(0, 101);
                            Result += (i + 1) + "." + ST[i].Name + ";" + ST[i].Bcc + ";" + ST[i].Database + ";" + ST[i].CSharp + "\r\n";
                        }
                        Display.Text= Result;
                        break;
                    case 1:
                        SFD.Filter = "文字檔|*.txt|ALL|*.*";
                        SFD.Title = "選擇儲存檔案";
                        if (SFD.ShowDialog() == DialogResult.OK)
                        {
                            File.WriteAllText(SFD.FileName, Display.Text);
                            System.Diagnostics.Process.Start(SFD.FileName);
                        }
                        break;
                    case 2:
                        Display.Text = "姓名: 計概+英文+國文+總成績(平均)\r\n";
                        OFD.Filter = "文字檔|*.txt";
                        OFD.Title = "請選擇來源檔案";
                        Result = null;                        
                        if (OFD.ShowDialog() == DialogResult.OK)
                        {
                            using (System.IO.StreamReader SR = new StreamReader(OFD.FileName))
                            {
                                while((Line = SR.ReadLine()) != null)
                                {
                                    string[] scores = Line.Split(';');
                                    Result += scores[0] + ":";
                                    Total = 0;
                                    for (int k=1; k < 4; k++)
                                    {
                                        Total += int.Parse(scores[k]);
                                        if (k < 3) Result += scores[k] + " + ";
                                        else Result += scores[k] + " = ";
                                    }
                                    Result +=Total + "("+Math.Round((double)Total/3,1)+")\r\n";
                                }
                                Display.Text += Result;
                            }
                        }
                        break;
                    case 3:
                        OFD.Filter = "文字檔|*.txt|ALL|*.*";
                        OFD.Title = "選擇儲存檔案";
                        if (OFD.ShowDialog() == DialogResult.OK)
                        {
                            System.Diagnostics.Process.Start(OFD.FileName);
                        }
                            break;
                    case 4:
                        SFD.Filter = "TXT|*.txt";
                        SFD.Title = "選擇儲存檔案";
                        if (SFD.ShowDialog() == DialogResult.OK)
                        {
                            using (System.IO.StreamWriter SW = new StreamWriter(SFD.FileName,false))
                            {
                                int LowerCase;
                                for (int i = 1; i <= NUD.Value; i++)
                                {
                                    Line = i + "." + ((char)RN.Next(65, 91)).ToString();
                                    LowerCase = RN.Next(3, 8);
                                    for (int j = 1; j <= LowerCase; j++)
                                    {
                                        Line += (char)RN.Next(97,123);
                                    }
                                    Line += ";" + RN.Next(0, 101) + ";" + RN.Next(0, 101) + ";" + RN.Next(0, 101) + "\r\n";
                                    SW.Write(Line);
                                }
                            }
                        }
                        System.Diagnostics.Process.Start(SFD.FileName);
                        break;
                    case 5:
                        SFD.Filter = "TXT|*.txt";
                        SFD.Title = "選擇儲存檔案";
                        if (SFD.ShowDialog() == DialogResult.OK)
                        {
                            string LastLine = File.ReadLines(SFD.FileName).Last();
                            int LastNo=int.Parse(LastLine.Substring(0, LastLine.IndexOf(".")));
                            using (System.IO.StreamWriter SW = new StreamWriter(SFD.FileName, true))
                            {
                                int LowerCase;
                                for (int i = LastNo+1; i <= NUD.Value+ LastNo; i++)
                                {
                                    Line = i + "." + ((char)RN.Next(65, 91)).ToString();
                                    LowerCase = RN.Next(3, 8);
                                    for (int j = 1; j <= LowerCase; j++)
                                    {
                                        Line += (char)RN.Next(97, 123);
                                    }
                                    Line += ";" + RN.Next(0, 101) + ";" + RN.Next(0, 101) + ";" + RN.Next(0, 101) + "\r\n";
                                    SW.Write(Line);
                                }
                            }
                        }
                        System.Diagnostics.Process.Start(SFD.FileName);
                        break;
                    case 6:
                        SFD.Filter = "文字檔|*.txt";
                        SFD.Title = "選擇儲存檔案";
                        OFD.Filter = "文字檔|*.txt";
                        OFD.Title = "選擇成績來源檔案";
                        string N3S;
                        if (SFD.ShowDialog() == DialogResult.OK)
                        {
                            using (StreamWriter SW = new StreamWriter(SFD.FileName, false))
                            {
                                if (OFD.ShowDialog() == DialogResult.OK)
                                {
                                    using (StreamReader SR = new StreamReader (OFD.FileName,Encoding.Default))
                                    {
                                        while ((Line = SR.ReadLine()) != null)
                                        {
                                            string[] scores = Line.Split(';');
                                            N3S = scores[0] + ":";
                                            Total = 0;
                                            for (int k = 1; k < 4; k++)
                                            {
                                                Total += int.Parse(scores[k]);
                                                if (k < 3)N3S += scores[k] + " + ";
                                                else N3S += scores[k] + " = ";
                                            }
                                            N3S += Total + "(" + Math.Round((double)Total / 3, 1) + ")\r\n";
                                            SW.WriteLine(N3S);
                                        }
                                        System.Diagnostics.Process.Start(OFD.FileName);
                                        System.Diagnostics.Process.Start(SFD.FileName);
                                    }
                                }
                            }
                        }
                            break;
                    case 7:
                        SFD.Filter = "PDF|*.pdf";
                        SFD.Title = "選擇儲存檔案";
                        OFD.Filter = "DOCX|*.docx|XLSX|*.xlsx|PPT|*.pptx";
                        OFD.Title = "選擇開啟來源檔案";
                        string FilePathPDF = null;
                        if(SFD.ShowDialog()==DialogResult.OK)
                        {
                            FilePathPDF = SFD.FileName;
                            if (OFD.ShowDialog() == DialogResult.OK)
                            {
                                System.IO.FileInfo FI = new FileInfo(OFD.FileName);
                                switch (FI.Extension)
                                {
                                    case ".docx":
                                        Office.Word.Application WORD = new Office.Word.Application();
                                        var wordfile = WORD.Documents.Open(OFD.FileName);
                                        wordfile.ExportAsFixedFormat(FilePathPDF, Office.Word.WdExportFormat.wdExportFormatPDF);
                                        wordfile.Close();
                                        WORD.Quit();
                                        System.Diagnostics.Process.Start(OFD.FileName);
                                        break;
                                    case ".xlsx":
                                        Office.Excel.Application EXCEL = new Office.Excel.Application();
                                        var excelfile = EXCEL.Workbooks.Open(OFD.FileName);
                                        excelfile.ExportAsFixedFormat(Office.Excel.XlFixedFormatType.xlTypePDF,FilePathPDF);
                                        excelfile.Close();
                                        EXCEL.Quit();
                                        System.Diagnostics.Process.Start(OFD.FileName);
                                        break;
                                    case ".pptx":
                                        Office.PowerPoint.Application PPT = new Office.PowerPoint.Application();
                                        var pptfile = PPT.Presentations.Open(OFD.FileName);
                                        pptfile.ExportAsFixedFormat(FilePathPDF, Office.PowerPoint.PpFixedFormatType.ppFixedFormatTypePDF);
                                        pptfile.Close();
                                        PPT.Quit();
                                        System.Diagnostics.Process.Start(OFD.FileName);
                                        break;
                                }
                                System.Diagnostics.Process.Start(SFD.FileName);
                            }
                        }
                        break;
                    case 8:
                        SFD.Filter = "ZIP|*.zip";
                        SFD.Title = "選擇儲存檔案";
                        folderBrowserDialog1.Description = "請選擇壓縮檔";
                        FolderBrowserDialog FBD = new FolderBrowserDialog();
                        if (SFD.ShowDialog() == DialogResult.OK)
                        {
                            if (FBD.ShowDialog() == DialogResult.OK)
                            {
                                this.Text = FBD.SelectedPath;
                                System.IO.Compression.ZipFile.CreateFromDirectory(FBD.SelectedPath, SFD.FileName);
                            }
                        }

                        break;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            { 

            }
        }

        private void Display_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
