﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS2020513B
{
    public partial class Form1 : Form
    {
        Random RN = new Random();
        int NUM;
        int count = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NUM = RN.Next(0, 10);
            this.Text += NUM + " , ";
            guess.Text = null;
            PGB.Value = 30;
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (PGB.Value == 0)
            {
                timer1.Enabled = false;
                MessageBox.Show("Game Over!", "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                PGB.PerformStep();
                Counter.Text = PGB.Value.ToString();
            }                     
        }        

        private void guess_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(guess.Text,out int result)&&result==NUM)
            {
                timer1.Enabled = false;
                MessageBox.Show("猜對了!", "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
