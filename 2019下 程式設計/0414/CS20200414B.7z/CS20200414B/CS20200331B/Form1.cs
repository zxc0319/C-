﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS20200331B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Random RN = new Random();
        string[] Names = new string[10000];
        int[] Scores = new int[10000];

        Student[] ST = new Student[10000];
        struct Student
        {
            public int Index;
            public string Name;
            public int Score;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string Name;
            string result = null;
            int NameLength,Num;
            Source.Clear();
            for (int i = 0; i < NUD.Value ; i++)
            {
                ST[i].Index = i;
                ST[i].Score = RN.Next(0, 101);
                Name = ((char)RN.Next(65, 91)).ToString();
                NameLength = RN.Next(3, 8);
                for (int j = 1; j < NameLength; j++)
                {
                    // 1.
                    //Name += ((char)RN.Next(97, 123)).ToString();
                    // 2.
                    while (true)
                    {
                        Num = RN.Next(48, 123);
                        if (Num >= 48 && Num <= 57 || Num >= 97 && Num <= 122)
                        {
                            Name += ((char)Num).ToString();
                            break;
                        }
                    }
                }
                ST[i].Name = Name;
                result += ST[i].Index + "." + ST[i].Name + "：" + ST[i].Score + System.Environment.NewLine;
            }
            Source.Text = result;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Display.Clear();
            string tempName;
            int tempScore,tempIndex;

            switch (comboBox1.SelectedIndex)
            {
                case 0: //Queue
                    for (int i = 0; i < NUD.Value ; i++)
                    {
                        //Display.Text += i + ". " + ST[i].Name + ": " + ST[i].Score + "\r\n";
                        Display.Text += ST[i].Index + ". " + ST[i].Name + ": " + ST[i].Score + "\r\n";
                    }
                        break;
                case 1: //Stack
                    for (int i = (int)NUD.Value-1; i >= 0; i--)
                    {
                        //Display.Text += i + ". " + ST[i].Name + ": " + ST[i].Score + "\r\n";
                        Display.Text += ST[i].Index + ". " + ST[i].Name + ": " + ST[i].Score + "\r\n";
                    }

                    break;
                case 2://成績
                    for (int i = 1; i < NUD.Value; i++)
                    {
                        for (int j = 1; j <= NUD.Value - i; j++)
                        {
                            if (ST[j - 1].Score > ST[j].Score)
                            {
                                tempName = ST[j - 1].Name;
                                ST[j - 1].Name = ST[j].Name;
                                ST[j].Name = tempName;

                                tempIndex = ST[j - 1].Index;
                                ST[j - 1].Index = ST[j].Index;
                                ST[j].Index = tempIndex;

                                tempScore = ST[j - 1].Score;
                                ST[j - 1].Score = ST[j].Score;
                                ST[j].Score = tempScore;

                            }
                        }
                    }
                    for (int i = (int)NUD.Value - 1; i >= 0; i--)
                    {
                        Display.Text += ST[i].Index + ". " + ST[i].Name + ": " + ST[i].Score + "\r\n";
                    }

                    break;
                case 3: //姓名
                    for (int i = 1; i < NUD.Value; i++)
                    {
                        for (int j = 1; j <= NUD.Value - i; j++)
                        {
                            if (string.Compare(ST[j - 1].Name,ST[j].Name)> 0)
                            {
                                tempName = ST[j - 1].Name;
                                ST[j - 1].Name = ST[j].Name;
                                ST[j].Name = tempName;

                                tempIndex = ST[j - 1].Index;
                                ST[j - 1].Index = ST[j].Index;
                                ST[j].Index = tempIndex;

                                tempScore = ST[j - 1].Score;
                                ST[j - 1].Score = ST[j].Score;
                                ST[j].Score = tempScore;

                            }
                        }
                    }
                    for (int i = 0; i < NUD.Value; i++)
                        {
                        Display.Text += ST[i].Index + ". " + ST[i].Name + ": " + ST[i].Score + "\r\n";
                    }
                    break;
                case 4: //成績 姓名
                    for (int i = 1; i < NUD.Value; i++)
                    {
                        for (int j = 1; j <= NUD.Value - i; j++)
                        {
                            if (ST[j - 1].Score > ST[j].Score)
                            {
                                tempName = ST[j - 1].Name;
                                ST[j - 1].Name = ST[j].Name;
                                ST[j].Name = tempName;

                                tempIndex = ST[j - 1].Index;
                                ST[j - 1].Index = ST[j].Index;
                                ST[j].Index = tempIndex;

                                tempScore = ST[j - 1].Score;
                                ST[j - 1].Score = ST[j].Score;
                                ST[j].Score = tempScore;
                            }
                            else if (ST[j - 1].Score == ST[j].Score)
                            {
                                if (string.Compare(ST[j - 1].Name, ST[j].Name) < 0)
                                {
                                    tempName = ST[j - 1].Name;
                                    ST[j - 1].Name = ST[j].Name;
                                    ST[j].Name = tempName;

                                    tempIndex = ST[j - 1].Index;
                                    ST[j - 1].Index = ST[j].Index;
                                    ST[j].Index = tempIndex;

                                    tempScore = ST[j - 1].Score;
                                    ST[j - 1].Score = ST[j].Score;
                                    ST[j].Score = tempScore;
                                }
                            }
                            
                                
                            
                        }
                      
                    }
                    for (int i = (int)NUD.Value - 1; i >= 0; i--)
                    {
                        Display.Text += ST[i].Index + ". " + ST[i].Name + ": " + ST[i].Score + "\r\n";
                    }
                    break;
            }
        }

        private void Source_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //button1_Click(null,null);
            button1.PerformClick();
        }

        private void NUD_Click(object sender, EventArgs e)
        {
            //button1.PerformClick();
        }

        private void NUD_DoubleClick(object sender, EventArgs e)
        {
            //button1.PerformClick();
        }

        private void NUD_ValueChanged(object sender, EventArgs e)
        {
            button1.PerformClick();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 FM2 = new Form2();
            FM2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.FormBorderStyle == FormBorderStyle.None)
            {
                this.FormBorderStyle = FormBorderStyle.Sizable;
                button3.Text = "Disable ControBox";
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                this.FormBorderStyle = FormBorderStyle.None;
                button3.Text = "Enable ControBox";
                this.WindowState = FormWindowState.Maximized;
            }
        }
    }
}
