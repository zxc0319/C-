﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS20200331B
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            MessageBox.Show("Say bye bye!!","提示訊息",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            switch (MessageBox.Show("請選擇[中止]?[重試]?{忽略]?","提示訊息",MessageBoxButtons.AbortRetryIgnore,MessageBoxIcon.Question))
            {
                case DialogResult.Abort:
                    Application.Exit();
                    break;

                case DialogResult.Retry:
                    //this.Close();
                    e.Cancel = false;
                    break;

                case DialogResult.Ignore:
                    e.Cancel = true;
                    break;
            }
        }
    }
}
