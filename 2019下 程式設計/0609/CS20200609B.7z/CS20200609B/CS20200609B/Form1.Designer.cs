﻿namespace CS20200609B
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.textBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.webBrowserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.動態產生ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.動態移除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.移除所有物件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("標楷體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.textBoxToolStripMenuItem,
            this.pictureBoxToolStripMenuItem,
            this.webBrowserToolStripMenuItem,
            this.buttonToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // textBoxToolStripMenuItem
            // 
            this.textBoxToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.textBoxToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.動態產生ToolStripMenuItem,
            this.動態移除ToolStripMenuItem,
            this.移除所有物件ToolStripMenuItem});
            this.textBoxToolStripMenuItem.Name = "textBoxToolStripMenuItem";
            this.textBoxToolStripMenuItem.Size = new System.Drawing.Size(98, 23);
            this.textBoxToolStripMenuItem.Text = "TextBox";
            // 
            // pictureBoxToolStripMenuItem
            // 
            this.pictureBoxToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.pictureBoxToolStripMenuItem.Name = "pictureBoxToolStripMenuItem";
            this.pictureBoxToolStripMenuItem.Size = new System.Drawing.Size(131, 23);
            this.pictureBoxToolStripMenuItem.Text = "PictureBox";
            this.pictureBoxToolStripMenuItem.Click += new System.EventHandler(this.pictureBoxToolStripMenuItem_Click);
            // 
            // webBrowserToolStripMenuItem
            // 
            this.webBrowserToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.webBrowserToolStripMenuItem.Name = "webBrowserToolStripMenuItem";
            this.webBrowserToolStripMenuItem.Size = new System.Drawing.Size(142, 23);
            this.webBrowserToolStripMenuItem.Text = "Web-Browser";
            // 
            // buttonToolStripMenuItem
            // 
            this.buttonToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonToolStripMenuItem.Name = "buttonToolStripMenuItem";
            this.buttonToolStripMenuItem.Size = new System.Drawing.Size(87, 23);
            this.buttonToolStripMenuItem.Text = "Button";
            this.buttonToolStripMenuItem.Click += new System.EventHandler(this.buttonToolStripMenuItem_Click);
            // 
            // 動態產生ToolStripMenuItem
            // 
            this.動態產生ToolStripMenuItem.Name = "動態產生ToolStripMenuItem";
            this.動態產生ToolStripMenuItem.Size = new System.Drawing.Size(215, 24);
            this.動態產生ToolStripMenuItem.Text = "動態產生";
            this.動態產生ToolStripMenuItem.Click += new System.EventHandler(this.動態產生ToolStripMenuItem_Click);
            // 
            // 動態移除ToolStripMenuItem
            // 
            this.動態移除ToolStripMenuItem.Name = "動態移除ToolStripMenuItem";
            this.動態移除ToolStripMenuItem.Size = new System.Drawing.Size(215, 24);
            this.動態移除ToolStripMenuItem.Text = "動態移除";
            this.動態移除ToolStripMenuItem.Click += new System.EventHandler(this.動態移除ToolStripMenuItem_Click);
            // 
            // 移除所有物件ToolStripMenuItem
            // 
            this.移除所有物件ToolStripMenuItem.Name = "移除所有物件ToolStripMenuItem";
            this.移除所有物件ToolStripMenuItem.Size = new System.Drawing.Size(215, 24);
            this.移除所有物件ToolStripMenuItem.Text = "移除所有物件";
            this.移除所有物件ToolStripMenuItem.Click += new System.EventHandler(this.移除所有物件ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem textBoxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 動態產生ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 動態移除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 移除所有物件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pictureBoxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem webBrowserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToolStripMenuItem;
    }
}

