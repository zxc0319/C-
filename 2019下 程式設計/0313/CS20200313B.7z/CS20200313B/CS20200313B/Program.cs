﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20200313B
{
    class Program
    {
        static void Main(string[] args)
        {
            Hello A = new Hello();
            Hello B = new Hello();
            Hello C = new Hello();

            A.Times("甲");
            B.Times("乙");
            C.Times("丙");

            A.Times("甲");
            //Console.WriteLine("甲班:" + A.ABC);
            //Console.WriteLine("乙班:" + B.ABC);
            //Console.WriteLine("丙班:" + C.ABC);
            B.Times("乙");
            //Console.WriteLine("甲班:" + A.ABC);
            //Console.WriteLine("乙班:" + B.ABC);
            //Console.WriteLine("丙班:" + C.ABC);
            C.Times("丙");
            //Console.WriteLine("甲班:" + A.ABC);
            //Console.WriteLine("乙班:" + B.ABC);
            //Console.WriteLine("丙班:" + C.ABC);

            Console.ReadKey();
        }
    }
}
