﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20200313B
{
    class Hello
    {
        //int ABC = 0;
        //private int ABC = 0;
        //public int ABC = 0;
        //static int ABC = 0;
        //public static int ABC = 0;
        //static public int ABC = 0;
        private public int ABC = 0;

        public void Times(string which) 
        {
            ABC++;
            Console.WriteLine(which + ": " + ABC);
        }
    }
}
