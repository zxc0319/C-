﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CS20200303B
{
    class Program
    {
        static System.Threading.Thread ThreadA, ThreadB, ThreadC;
        static Random RN = new Random();
        static int A, B, C, Nth, SleepTime;

        static void Main(string[] args)
        {
            while(true)
            {
                try
                {
                    checked
                    {
                        Console.Write("Press Y(y) for Continue Else for No？ Nth？ SleepTime(ms)？");
                        string[] YN = Console.ReadLine().Split(' ');
                        Nth = int.Parse(YN[1]);
                        SleepTime = int.Parse(YN[2]);
                        if (YN[0] == "Y" || YN[0] == "y")
                        {
                            A = 0; B = 0; C = 0;
                            ThreadA = new Thread(new ThreadStart(IMA));
                            ThreadB = new Thread(new ThreadStart(IMB));
                            ThreadC = new Thread(new ThreadStart(IMC));
                            ThreadA.Start();
                            ThreadB.Start();
                            ThreadC.Start();
                        }
                        else return;
                    }
                }
                catch(Exception ex) 
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    Console.ReadKey();
                }
            }
                
        }

        private static void IMB()
        {
            while (true)
            {
                Thread.Sleep(RN.Next(0, SleepTime));
                B++;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("資一乙(" + B + ")：" + DateTime.Now.ToLongTimeString() + "\n");
                Console.ForegroundColor = ConsoleColor.White;
                if (B == Nth)
                {
                    ThreadA.Abort();
                    ThreadC.Abort();
                    Console.WriteLine("Winner：資一乙");
                    ThreadB.Abort();

                }
            }
        }

        private static void IMA()
        {
            while (true)
            {
                Thread.Sleep(RN.Next(0, SleepTime));
                A++;
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("資一甲(" + A + ")：" + DateTime.Now+ "\n");
                Console.ForegroundColor = ConsoleColor.White;
                if (A == Nth)
                {
                    ThreadB.Abort();
                    ThreadC.Abort();
                    Console.WriteLine("Winner：資一甲");
                    ThreadA.Abort();
                }
            }
        }
        private static void IMC()
        {
            while (true)
            {
                Thread.Sleep(RN.Next(0, SleepTime));
                C++;
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("資一丙(" + C + ")：" + DateTime.Now + "\n");
                Console.ForegroundColor = ConsoleColor.White;
                if (C == Nth)
                {
                    ThreadB.Abort();
                    ThreadA.Abort();
                    Console.WriteLine("Winner：資一丙");
                    ThreadC.Abort();
                }
            }
        }

    }
}
