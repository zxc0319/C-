﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20200310B
{
    class Functions
    {
        public decimal Factorial(uint n)
        {
            decimal F;
            if (n == 0) F = 1;
            else
            {
                F = 1;
                for (int i = 1; i <= n; i++)
                {
                    F = F * i; //F = F * i; F *= i;
                }
            }
            return F;
        }
    }
}
