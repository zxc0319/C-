﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS20200421B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random RN = new Random();
        STUDENT[] ST = new STUDENT[100000];
        struct STUDENT
        {
            public string Name;
            public int Bcc;
            public int Database;
            public int CSharp;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (ComboBox1.SelectedIndex)
                {
                    case 0:
                        Display.Clear();
                        string Result = null;
                        for(int i =0;i<NUD.Value;i++)
                        {
                            int NameLength;
                            ST[i].Name = ((char)RN.Next(65, 91)).ToString();                             
                            NameLength = RN.Next(3, 8);
                            for (int j = 1; j <= NameLength; j++)
                            {
                                ST[i].Name += ((char)RN.Next(97, 123)).ToString();
                            }
                            ST[i].Bcc = RN.Next(0, 101);
                            ST[i].Database = RN.Next(0, 101);
                            ST[i].Database = RN.Next(0, 101);
                            Result += (i + 1) + "." + ST[i].Name + "：" + ST[i].Bcc + "," + ST[i].Database + "," + ST[i].CSharp + "\r\n";
                        }
                        Display.Text= Result;
                        break;
                    case 1:
                        SFD.Filter = "文字檔|*.txt|ALL|*.*";
                        SFD.Title = "選擇儲存檔案";
                        if (SFD.ShowDialog() == DialogResult.OK)
                        {
                            System.IO.File.WriteAllText(SFD.FileName, Display.Text);
                            System.Diagnostics.Process.Start(SFD.FileName);
                        }

                        break;
                    case 2:
                        break;
                    case 3:
                        OFD.Filter = "文字檔|*.txt|ALL|*.*";
                        OFD.Title = "選擇儲存檔案";
                        if (OFD.ShowDialog() == DialogResult.OK)
                        {
                            System.Diagnostics.Process.Start(OFD.FileName);
                        }
                            break;
                    case 4:
                        break;
                    case 5:
                        break;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            { 

            }
        }
    }
}
