﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using VB = Microsoft.VisualBasic;

namespace CS20200324B
{
    public partial class Form1 : Form
    {
        Thread threadA, threadB;
        Random RN = new Random();
        int A, B;
        bool running = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Display_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("Form Load Event", "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Display.Text = DateTime.Now.ToString();
            Form.CheckForIllegalCrossThreadCalls = false;

        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            this.Text = VB.Interaction.InputBox("Input Text?","visual Basuc Inputox");

            
        }

        private void Display_DoubleClick(object sender, EventArgs e)
        {
            Display.Text = DateTime.Now.ToString();
        }

        private void Display_MouseEnter(object sender, EventArgs e)
        {
            Display.Text = DateTime.Now.ToString();
        }

        private void Display_MouseLeave(object sender, EventArgs e)
        {
            Display.Text = "資管一乙";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Display.Text = DateTime.Now.ToString();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = !timer1.Enabled;
            if (timer1.Enabled)
            {
                swich.Text = "OFF";
                swich.BackColor = Color.Green;
            }
            else 
            {
                swich.Text = "ON";
                swich.BackColor = Color.Red;
            }
        }

        private void Nth_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar)&& e.KeyChar!=8)
            {
                this.Text = e.KeyChar.ToString();
                e.Handled = true;
            }
            
            
        }

        private void Nth_TextChanged(object sender, EventArgs e)
        {

            if (!uint.TryParse(Nth.Text, out uint result)) Nth.Text = "5"; //沒有負數的int 
            
            //if (!byte.TryParse(Nth.Text, out byte result)) Nth.Text = "5"; 0~255位元
            
            //if (!int.TryParse(Nth.Text, out int result)) Nth.Text = "5"; 小於0轉換
            //if (result <= 0) Nth.Text = "5";
        }

        private void DisplayA_TextChanged(object sender, EventArgs e)
        {

        }

        private void DisplayB_TextChanged(object sender, EventArgs e)
        {

        }

        private void SleepTime_TextChanged(object sender, EventArgs e)
        {
            if (!uint.TryParse(SleepTime.Text, out uint result)) SleepTime.Text = "3000";
        }



        private void SC_Click(object sender, EventArgs e)
        {
            running = !running;
            if (running)
            {
                SC.Text = "取消";
                SC.BackColor = Color.Green;
                A = 0;B = 0;
                threadA = new Thread(new ThreadStart(IMA));
                threadB = new Thread(new ThreadStart(IMB));
                threadA.Start(); threadB.Start();  //開始            

            }
            else
            {
                SC.Text = "啟動";
                SC.BackColor = Color.Red;
                DisplayA.Clear(); ;DisplayB.Clear();
                threadA.Abort(); threadB.Abort(); //停止                
            }
        }

        private void button1_DockChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Random RN = new Random();
            Form2 fm2 = new Form2();
            fm2.ShowDialog();
        }

        private void IMA() 
        {
            try
            {
                while (true)
                {
                    Thread.Sleep(RN.Next(0, int.Parse(SleepTime.Text)));
                    A++;
                    DisplayA.Text += "資一甲(" + A + "):" + System.DateTime.Now + "\n";
                    if (A ==int.Parse(Nth.Text))
                    {
                        threadB.Abort();
                        DisplayA.Text += "Winner:資一甲";
                        threadA.Abort();
                    }
                }
            }
            catch (Exception EX)
            {
                MessageBox.Show("IMA"+EX, "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {

            }

        }
        private void IMB()
        {
            try
            {
                while (true)
                {
                    Thread.Sleep(RN.Next(0, int.Parse(SleepTime.Text)));
                    B++;
                    DisplayB.Text += "資一乙(" + B + "):" + System.DateTime.Now + "\n";
                    if (B == int.Parse(Nth.Text)) 
                    {
                        threadA.Abort();
                        DisplayB.Text += "Winner:資一乙";
                        threadB.Abort();
                    }
                }
            }
            catch (Exception EX)
            {
                MessageBox.Show("IMB"+EX, "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {

            }
        }
    }
}
