﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS20200331B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Random RN = new Random();
        string[] Names = new string[10000];
        int[] Scores = new int[10000];

        Student[] ST = new Student[10000];
        struct Student
        {
            public string Name;
            public int Score;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string Name;
            string result = null;
            int NameLength,Num;
            Source.Clear();
            for (int i = 1; i < NUD.Value + 1; i++)
            {                
                ST[i].Score = RN.Next(0, 101);
                Name = ((char)RN.Next(65, 91)).ToString();
                NameLength = RN.Next(3, 8);
                for (int j = 1; j < NameLength; j++)
                {
                    // 1.
                    //Name += ((char)RN.Next(97, 123)).ToString();
                    // 2.
                    while (true)
                    {
                        Num = RN.Next(48, 123);
                        if (Num >= 48 && Num <= 57 || Num >= 97 && Num <= 122)
                        {
                            Name += ((char)Num).ToString();
                            break;
                        }
                    }
                }
                ST[i].Name = Name;
                result += i + "." + ST[i].Name + "：" + ST[i].Score + System.Environment.NewLine;
            }
            Source.Text = result;
        } 
    }
}
