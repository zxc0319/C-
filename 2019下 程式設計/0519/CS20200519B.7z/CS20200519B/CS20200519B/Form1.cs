﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS20200519B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Random RN = new Random();
        private void STNum_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(STNum.Text, out int result) || result < 0)
            {
                STNum.Text = "0";
                return;
            }
            checkedListBox1.Items.Clear();
            checkedListBox1.Items.Add("Name→ 計概 + 英文 + 國文 = 總分 " );
            int[,] StudentScores = new int[result, 4];
            int NameLength;
            string FamilyName;
            for (int i = 0; i < int.Parse(STNum.Text); i++)
            {
                NameLength = RN.Next(3, 8);
                //FamilyName = ((char)(65 + RN.Next(0, 26))).ToString();
                FamilyName = ((char)(RN.Next('A', 'Z' + 1))).ToString();
                for (int j = 1; j <= 3; j++)
                {
                    //FamilyName += (char)(97 + RN.Next(0, 26));
                    FamilyName += (char)(RN.Next('a', 'z' + 1));
                }
                for (int k = 1; k <= 3; k++)
                {
                    StudentScores[i, k] = RN.Next(0, 101);
                    StudentScores[i, 0] += StudentScores[i, k];
                }
                checkedListBox1.Items.Add(FamilyName + "： " 
                    + StudentScores[i, 1] + " + " + StudentScores[i, 2] + " + " + StudentScores[i, 3]
                    + " = " + StudentScores[i, 0]);
            }            
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (string item in checkedListBox1.CheckedItems)
            {
                listBox1.Items.Add(item);
            }
        }
    }
}
