﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS20200519B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Random RN = new Random();
        private void STNum_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(STNum.Text, out int result) || result < 0)
            {
                STNum.Text = "0";
                return;
            }
            checkedListBox1.Items.Clear();
            checkedListBox1.Items.Add("Name→ 計概 + 英文 + 國文 = 總分 " );
            int[,] StudentScores = new int[result, 4];
            int NameLength;
            string FamilyName;
            for (int i = 0; i < int.Parse(STNum.Text); i++)
            {
                NameLength = RN.Next(3, 8);
                //FamilyName = ((char)(65 + RN.Next(0, 26))).ToString();
                FamilyName = ((char)(RN.Next('A', 'Z' + 1))).ToString();
                for (int j = 1; j <= 3; j++)
                {
                    //FamilyName += (char)(97 + RN.Next(0, 26));
                    FamilyName += (char)(RN.Next('a', 'z' + 1));
                }
                for (int k = 1; k <= 3; k++)
                {
                    StudentScores[i, k] = RN.Next(0, 101);
                    StudentScores[i, 0] += StudentScores[i, k];
                }
                checkedListBox1.Items.Add(FamilyName + "： " 
                    + StudentScores[i, 1] + " + " + StudentScores[i, 2] + " + " + StudentScores[i, 3]
                    + " = " + StudentScores[i, 0]);
            }            
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (string item in checkedListBox1.CheckedItems)
            {
                 if(item.Substring(4,1)!="→") listBox1.Items.Add(item);
            }
            Counter.Text = listBox1.Items.Count.ToString();
        }

        private void SelectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= checkedListBox1.Items.Count - 1; i++)
            {
                checkedListBox1.SetItemChecked(i, true);
            }
        }

        private void English_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            int pos1, pos2,Eng;
            for (int i = 1; i < checkedListBox1.Items.Count; i++)
            {
                pos1 = checkedListBox1.Items[i].ToString().IndexOf("+");
                pos2 = checkedListBox1.Items[i].ToString().IndexOf("+",pos1+1);
                Eng = int.Parse(checkedListBox1.Items[i].ToString().Substring(pos1 + 2, pos2 - (pos1+2) -1));
                listBox2.Items.Add(Eng);
                if (Eng >= 60)
                {
                    listBox1.Items.Add(checkedListBox1.Items[i]);
                }
            }
        }

        private void listBox1_MouseEnter(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0) return;
            int Equa1_position, Name_position;

            int Score;
            string Name;

            int No1_score = 0;string No1_name = null;
            int Lowest_score = 100; string Lowest_name = null;

        }

        private void listBox1_MouseLeave(object sender, EventArgs e)
        {
            Highest.Text = "";
            Lowest.Text = "";
        }
    }
}
