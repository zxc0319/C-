﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monte_Carlo_method
{
    class Program
    {
        static void Main(string[] args)
        {
            //Random RN = new Random();
            RandomNumberGenerator RAG = new RandomNumberGenerator(); // 自製亂數
            double X, Y;
            int C;
            //Console.WriteLine(RAG.Randomize());
            while (true)
            {
                Console.Write("Input number of times for (x,y)?");
                int T = int.Parse(Console.ReadLine());//
                C = 0;
                Console.WriteLine(DateTime.Now.ToLongTimeString());
                for (int i = 1; i <= T; i++)
                {
                    //X = RN.NextDouble();
                    //Y = RN.NextDouble();
                    X = RAG.Randomize();
                    Y = RAG.Randomize();
                    if ((X * X + Y * Y) <= 1) C++; //曲線內C++ 
                }
                Console.WriteLine("1/4 Circular area(Monte Carlo Method):" + Math.Round((double)C / T, 8));
                Console.WriteLine("1/4 Circular area(Monte Carlo Method):" + Math.Round(Math.PI * 1.0 * 1.0 / 4.0, 8));
                Console.WriteLine("1/4 Circular area(Monte Carlo Method):" + Math.Round(3.14159265359 / 4.0, 8));
                Console.WriteLine("1/4 Circular area(Monte Carlo Method):" + Math.Round((22.0 / 7.0) / 4.0, 8));

                Console.WriteLine(DateTime.Now.ToShortTimeString());
                Console.ReadKey();
            }
        }
    }
    class RandomNumberGenerator
    {
        public double Randomize()
        {
            double T = DateTime.Now.TimeOfDay.TotalMilliseconds;
            long TT = (long)(T * 1000) * (long)(T * 1000);
            //Console.WriteLine(TT);
            string ST = TT.ToString();
            int pos = ST.Length / 2;
            return double.Parse(("0." + ST.Substring(pos - 2, 5)));
        }
    }
}
