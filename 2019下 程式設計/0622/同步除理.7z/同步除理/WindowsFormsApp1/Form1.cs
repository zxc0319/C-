﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void radioButton_CheckedChanged(object sender, EventArgs e)
        {
            //1.
            //if (radioButton1.Checked) this.Text = radioButton1.Text;
            //if (radioButton2.Checked) this.Text = radioButton2.Text;
            //if (radioButton3.Checked) this.Text = radioButton3.Text;
            //if (radioButton4.Checked) this.Text = radioButton4.Text;

            //2.
            RadioButton RB = sender as RadioButton;
            this.Text = RB.Text;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (int.Parse(Counter.Text) == 0)
            {
                if (Red.Checked) Green.Checked = true;
                else if (Green.Checked) Yellow.Checked = true;
                else if (Yellow.Checked) Red.Checked = true;
            }            
            else
            {
                Counter.Text = (int.Parse(Counter.Text) - 1).ToString();
            }               
            if (Red.Checked && int.Parse(Counter.Text) == 5) KY.Checked = true;          
        }
        private void Red_CheckedChanged(object sender, EventArgs e)
        {
            if (Red.Checked)
            {
                Counter.Text = "20";
                KG.Checked = true;
            }
        }

        private void Yellow_CheckedChanged(object sender, EventArgs e)
        {
            if (Yellow.Checked)
            {
                Counter.Text = "5";
                KR.Checked = true;
            }
        }

        private void Green_CheckedChanged(object sender, EventArgs e)
        {
            if (Green.Checked)
            {
                Counter.Text = "20";
                KR.Checked = true;
            }
        }

        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            this.Text = null;
            if (checkBox1.Checked) this.Text += checkBox1.Text + " : ";
            if (checkBox2.Checked) this.Text += checkBox2.Text + " : ";
            if (checkBox3.Checked) this.Text += checkBox3.Text + " : ";
            if (checkBox4.Checked) this.Text += checkBox4.Text + " : ";
        }
    }
}
