﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20200303B
{
    class Program
    {
        Random RN = new Random();
        int A, B, C, Nth, SleepTime;

        static void Main(string[] args)
        {
            while(true)
            {
                try
                {
                    checked
                    {
                        Console.Write("Press Y(y) for Continue Else for No？ Nth？ SleepTime(ms)？");
                        string[] YN = Console.ReadLine().Split(' ');
                    }
                }
                catch(Exception ex) 
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    Console.ReadKey();
                }
            }
                
        }
    }
}
