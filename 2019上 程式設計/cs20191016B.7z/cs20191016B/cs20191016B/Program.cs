﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs20191016B
{
    class Program
    {
        static void Main(string[] args)
        {
            int Chi, Eng, Mat, P1, P2, Totle;
            while (true)
                try
                {
                    Console.WriteLine("四技二專成績計算模擬[國文 英文 數學 專一 專二]");
                    Console.Write("請選擇[1]Input單人五科分數 [2]Input人數自動產生分數 [其他]結束 ？");
                    string which = Console.ReadLine();


                    checked
                    {
                        switch (which)
                        {
                            case "1":
                                Console.WriteLine("Input 國文？英文？數學？專一？專二？");
                                string[] str = Console.ReadLine().Split(' ');

                                //if (str[0] == "") return;
                                //if (str[1] == "") return;
                                //if (str[2] == "") return;
                                //if (str[3] == "") return;
                                //if (str[4] == "") return;
                                if (str[0] == ""|| str[1] == ""|| str[2] == ""|| str[3] == ""|| str[4] == "") return;

                                Chi = int.Parse(str[0]);
                                Eng = int.Parse(str[1]);
                                Mat = int.Parse(str[2]);
                                P1 = int.Parse(str[3]);
                                P2 = int.Parse(str[4]);
                                Totle = Chi + Eng + Mat + P1 * 2 + P2 * 2;
                                Console.WriteLine(Chi+" + "+Eng+" + "+Mat+" + "+P1+"*2 + "+P2+"*2 = "+Totle );
                                Console.WriteLine(Chi + "[國文] + " + Eng + "[英文] + " + Mat + "[數學] + " + P1 + "[專一]*2 + " + P2 + "[專二]*2 = " + Totle+"[總分]");

                                break;
                            case "2":
                                Console.WriteLine("考生人數？產生單筆資料速度(一秒=1000)？");
                                string[] X = Console.ReadLine().Split(' ');
                                Random rdm1 = new Random(unchecked((int)DateTime.Now.Ticks));

                                Chi = rdm1.Next(1, 100);
                                Eng = rdm1.Next(1, 100);
                                Mat = rdm1.Next(1, 100);
                                 P1 = rdm1.Next(1, 100);
                                 P2 = rdm1.Next(1, 100);
                                Totle = Chi + Eng + Mat + P1 * 2 + P2 * 2;
                                Console.WriteLine(Chi + " + " + Eng + " + " + Mat + " + " + P1 + "*2 + " + P2 + "*2 = " + Totle);







                                ;

                                break;
                            default:
                                return;
                        }
                            

                    }
                }
                catch(Exception e)
                {
                    //Console.WriteLine(e.ToString());
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    Console.WriteLine("Press any key to continue!!\n\n");
                    Console.ReadKey();
                }
        }
    }
}
