﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20191218
{
    class Program
    {
        static void Main(string[] args)
        {
            string A = ("4. Qgos：73 + 98 + 86 = 257");
            string B = ("10. Tsnmust：21 + 73 + 23 = 117");
            Console.WriteLine("A == " + A);
            Console.WriteLine("B == " + B);

            int posA = A.IndexOf("+");
            int posB = A.IndexOf("+",posA+1);
            int posC = B.IndexOf("+");
            int posD = B.IndexOf("+",posC+1);
            string A2 = A.Substring(posA + 2, posB - posA - 3);
            string B2 = B.Substring(posC + 2, posD - posC - 3);

            Console.WriteLine("Index of string A(1st +)== " + posA);
            Console.WriteLine("Index of string A(2nd +)== " + posB);
            Console.WriteLine("Index of string B(1st +)== " + posC);
            Console.WriteLine("Index of string B(2nd +)== " + posD);

            Console.WriteLine("2nd Score of sring A == " + A2);
            Console.WriteLine("2nd Score of sring B == " + B2);


            //int pos1 = A.IndexOf(".");
            //int pos2 = A.IndexOf("：");
            //int pos3 = B.IndexOf(".");
            //int pos4 = B.IndexOf("：");
            //string A_Name = A.Substring(pos1 + 2, pos2 - pos1 - 2);
            //string B_Name = B.Substring(pos3 + 2, pos4 - pos3 - 2);

            //Console.WriteLine("Index of string A(.)== "+pos1);
            //Console.WriteLine("Index of string A(：)== " + pos2);
            //Console.WriteLine("Index of string B(.)== " + pos3);
            //Console.WriteLine("Index of string B(：)== " + pos4);
            //Console.WriteLine("nameof of string A == " + A_Name);
            //Console.WriteLine("nameof of string B == " + B_Name);

            Console.ReadKey();
        }
    }
}
