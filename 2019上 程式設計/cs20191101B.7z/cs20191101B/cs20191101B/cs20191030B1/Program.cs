﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs20191030B1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine( "\n\n" + System.DateTime.Now);
                    Console.Write("[A]Factorial？？  [B] Fibonacci？？  [C] Prime Number？  [D] GCD[LCM] = (Input Number：？？)");
                    string[] Line = Console.ReadLine().Split(' ');
                    if (Line[0] == "") break;
                    string which = Line[0];
                    checked
                    {
                        switch (which)
                        {
                            case "A":
                                for (int n = int.Parse(Line[1] ); n <= int.Parse(Line[2]); Factorial(n)) ;
                                {
                                    Console.WriteLine(n + "!= " +  Factorial(n) );
                                }
                                //int N = int.Parse(Line[1]);                                
                                //int M = 1;
                                //DE F = 1;
                                //if (N < 0)
                                //{
                                //    Console.WriteLine("N!輸入直 >= 0");
                                //    return;
                                //}
                                //else if (N == 0)
                                //{
                                //    Console.WriteLine("定義0! = 1");
                                //    break;
                                //}
                                ////while ((M!=N) )
                                ////{                                    
                                ////    M = M + 1;
                                ////    F = F * M;                                    
                                ////}\
                                //for(int i= 1; i<=N ;i++)
                                //{
                                //    F = F * i;
                                //}
                                //Console.WriteLine(N + "!= " + F);

                                break;
                            case "B":
                                break;
                            case "C":
                                break;
                            case "D":
                                break;
                            default:
                                return;



                        }
                       

                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                finally
                {
                    Console.ReadKey();
                }
                
            }
            


        }
        
        static decimal Factorial(int X)
        {
            decimal F;
            if (X == 0) F = 1;
            else
            {
                F = 1;
                for(int M =1; M<=X; M++)
                {
                    F = F * M;
                }
            }
            return F;
        }
    }
}   
