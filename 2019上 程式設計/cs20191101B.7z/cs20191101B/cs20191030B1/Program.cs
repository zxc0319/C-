﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs20191030B1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine( "\n\n" + System.DateTime.Now);
                    Console.WriteLine("[A]Factorial？？  [B] Fibonacci？？  [C] Prime Number？  [D] GCD[LCM] = (Input Number：？？)");
                    string[] Line = Console.ReadLine().Split(' ');
                    if (Line[0] == "") break;
                    string which = Line[0];
                    checked
                    {
                        switch (which)
                        {
                            case "A":
                                string x = Line[1];



                                break;
                            case "B":
                                break;
                            case "C":
                                break;
                            case "D":
                                break;
                            default:
                                return;



                        }
                       

                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                finally
                {
                    Console.ReadKey();
                }
                
            }
            


        }
    }
}
