﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20191204B
{
    class Program
    {
        static void Main(string[] args)
        {
            Random RN = new Random();
            while (true)
            {
                try
                {
                    Console.Write("INPUT number of digit & times？");
                    string[] Line = Console.ReadLine().Split(' ');
                    int digit = int.Parse(Line[0]);
                    int times = int.Parse(Line[1]);
                    checked
                    {
                        int number;
                        string ID;
                        for(int i = 1; i <= times; i++)
                        {
                            number = RN.Next((int)Math.Pow(10, digit - 1), (int)Math.Pow(10, digit));
                            //Console.WriteLine(i + ". " + number+"\n");
                            Console.WriteLine(i + ". " + number + " : " + OddEven(number) + "\n");

                            //ID = null;
                            //for (int j = 1; j <= digit; j++)
                            //{
                            //    ID = ID + RN.Next(0, 10);
                                
                            //}
                            //Console.WriteLine(i + ". " + ID + "\n");
                        }
                    }
                }
                catch(Exception X)
                {
                    Console.WriteLine(X.ToString());
                }
                finally
                {

                }
            }
        }
        static string OddEven(int N)
        {
            int Odd = 0;
            int Even = 0;
            //int Q, R;
            //while (true)
            //{
            //    R = N % 10;
            //    if (R % 2 == 0) Even++;
            //    else Odd++;
            //    Q = N / 10;
            //    if (Q == 0) break;
            //    else N = Q;
            //}

            string S = N.ToString();
            for(int i = 0; i <= S.Length - 1; i++)
            {
                if (int.Parse(S.Substring(i, 1)) % 2 == 0) Even++;
                else Odd++;
            }

            return "奇(" + Odd + ")偶(" + Even + ")";           
        }
    }
}
