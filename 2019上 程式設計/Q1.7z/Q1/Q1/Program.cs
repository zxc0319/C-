﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("&(字串結合)；/ (小數點兩位)；% (餘數)；^(冪指數)");
                    Console.WriteLine(" * (乘法)；X(乘法Bonus：987654321 X 123456789123456789)");
                    Console.WriteLine("Input Operator(&+*/% ^)？ Two Operands(Integer)？");
                    string[] str = Console.ReadLine().Split(' ');
                    Console.ForegroundColor = ConsoleColor.Red;
                    checked
                    {
                        if(str[0] == "&")
                        {
                            Console.Write(str[1] + " & " + str[2] + " = ");
                            Console.WriteLine(str[1] + str[2]);
                        }
                        else if (str[0] == "+")
                        {
                            Console.Write(str[1] + " + " + str[2] + " = ");
                            Console.WriteLine(long.Parse(str[1]) + long.Parse(str[2]));
                        }
                        else if (str[0] == "*")
                        {
                            Console.Write(str[1] + " * " + str[2] + " = ");
                            Console.WriteLine(long.Parse(str[1]) * long.Parse(str[2]));
                        }
                        else if (str[0] == "X")
                        {
                            Console.Write(str[1] + " X " + str[2] + " = ");
                            Console.WriteLine(decimal.Parse(str[1]) * decimal.Parse(str[2]));
                        }
                        else if (str[0] == "/")
                        {
                            Console.Write(str[1] + " / " + str[2] + " = ");
                            Console.WriteLine(Math.Round(double.Parse(str[1]) + double.Parse(str[2]), 2));
                        }
                        else if (str[0] == "%")
                        {
                            Console.Write(str[1] + " + " + str[2] + " = ");
                            Console.WriteLine(long.Parse(str[1]) % long.Parse(str[2]));
                        }
                        else if (str[0] == "^")
                        {
                            Console.Write(str[1] + " + " + str[2] + " = ");
                            Console.WriteLine(Math.Pow(long.Parse(str[1]), long.Parse(str[2])));
                        }
                        else 
                        {
                            return;  
                        }


                        switch (str[0])
                        {
                            case "&":
                                Console.Write(str[1] + " & " + str[2] + " = ");
                                Console.WriteLine(str[1] + str[2]);
                                break;
                            case "+":
                                Console.Write(str[1] + " + " + str[2] + " = ");
                                Console.WriteLine(long.Parse(str[1]) + long.Parse(str[2]));
                                break;
                            case "*":
                                Console.Write(str[1] + " * " + str[2] + " = ");
                                Console.WriteLine(long.Parse(str[1]) * long.Parse(str[2]));
                                break;
                            case "X":
                                Console.Write(str[1] + " X " + str[2] + " = ");
                                Console.WriteLine(decimal.Parse(str[1]) * decimal.Parse(str[2]));
                                break;
                            case "/":
                                Console.Write(str[1] + " / " + str[2] + " = ");
                                Console.WriteLine(Math.Round(double.Parse(str[1]) + double.Parse(str[2]), 2));
                                break;
                            case "%":
                                Console.Write(str[1] + " + " + str[2] + " = ");
                                Console.WriteLine(long.Parse(str[1]) % long.Parse(str[2]));
                                break;
                            case "^":
                                Console.Write(str[1] + " + " + str[2] + " = ");
                                Console.WriteLine(Math.Pow(long.Parse(str[1]), long.Parse(str[2])));
                                break;
                            default:
                                return;
                        }

                    }
                }
                catch(Exception e)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine(e.ToString());
                    Console.ForegroundColor = ConsoleColor.White;
                }
                finally
                {
                    Console.ForegroundColor = ConsoleColor.White;                    
                    Console.WriteLine("Hello！第一次程式小考。");
                    Console.WriteLine("");
                }
            }
        }
    }
}
          