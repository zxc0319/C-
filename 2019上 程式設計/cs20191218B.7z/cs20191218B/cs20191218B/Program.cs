﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20191218B
{
    class Program
    {
        static void Main(string[] args)
        {
            Random RN = new Random();
            while (true)
            {
                try
                {
                    Console.Write("INPUT number of Student？Max. Length of Last Name？Sorting by Score/Name[S(Descending)/N(Ascending)/SN]？");
                    string[] line = Console.ReadLine().Split(' ');
                    int number = int.Parse(line[0]);
                    int NameLength = int.Parse(line[1]);

                    string Name;
                    int BCC, CSharp, DS, Total;
                    int[] Scores = new int[1000];
                    string[] ST = new string[1000];
                    for (int i = 1; i <= number; i++)
                    {
                        Name = ((char)RN.Next(65, 91)).ToString();
                        for(int j=1;j<=RN.Next(1,NameLength); j++)
                        {
                            Name += (char)RN.Next(97, 123);
                        }

                        BCC = RN.Next(0, 101);
                        CSharp = RN.Next(0, 101);
                        DS = RN.Next(0, 101);
                        Total = BCC + CSharp + DS;

                        Scores[i - 1] = Total;
                        ST[i - 1] = i + ". " + Name + " : " + BCC + " + " + CSharp + " + " + DS + " = ";

                        //Console.WriteLine(i+"."+Name+" : "+BCC+" + "+CSharp+" + "+DS+" = "+Total+"\n");
                    }
                    //Console.WriteLine("======================================================");
                    for(int k = 0; k <= number - 1; k++)Console.WriteLine(ST[k] + Scores[k]);
                    int temp;
                    string tempp;
                    int pos1, pos2, pos3, pos4;
                    string F_Name, S_Name;
                    switch (line[2])
                    {
                        case "S":
                            for (int n = 1; n < number; n++) //Round
                            {
                                for (int j = 1; j <= number - n; j++) //比較次數
                                {
                                    if (Scores[j - 1] > Scores[j])
                                    {
                                        temp = Scores[j];
                                        Scores[j] = Scores[j-1];
                                        Scores[j-1] = temp;

                                        tempp = ST[j];
                                        ST[j] = ST[j - 1];
                                        ST[j - 1] = tempp;                                        
                                    }
                                }                                
                            }
                            Console.WriteLine("======================================================");
                            //小到大
                            for (int k = 0; k <= number - 1; k++) Console.WriteLine(ST[k] + Scores[k]);                            
                            //大到小
                            //for (int k = number-1; k >= 0; k--) Console.WriteLine(ST[k] + Scores[k]);
                            break;

                        case "N":
                            for (int n = 1; n < number; n++) //Round
                            {
                                for (int j = 1; j <= number - n; j++) //比較次數
                                {
                                    pos1 = ST[j - 1].IndexOf(". ");
                                    pos2 = ST[j - 1].IndexOf(" : ");
                                    pos3 = ST[j].IndexOf(". ");
                                    pos4 = ST[j].IndexOf(" : ");
                                    F_Name = ST[j - 1].Substring(pos1 + 2, pos2 - pos1 - 2);
                                    S_Name = ST[j].Substring(pos3 + 2, pos4 - pos3 - 2);

                                    if (string.Compare(F_Name, S_Name) >0)
                                    {                                        
                                        temp = Scores[j];
                                        Scores[j] = Scores[j - 1];
                                        Scores[j - 1] = temp;

                                        tempp = ST[j];
                                        ST[j] = ST[j - 1];
                                        ST[j - 1] = tempp;
                                    }
                                }
                            }
                            Console.WriteLine("======================================================");
                            for (int k = 0; k <= number - 1; k++) Console.WriteLine(ST[k] + Scores[k]);
                            break;

                        case "SN":


                        break;

                        default:
                            break;
                    }
                    
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    Console.WriteLine();
                }

            }

            
        }
    }
}
