﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20191122B
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                double Strart = 0;
                double Finish = 0;
                try
                {
                    checked
                    {
                        int counter = 0;
                        Strart = System.DateTime.Now.TimeOfDay.TotalSeconds;
                        for (int n1 = 1; n1 <= 9; n1++)
                        {
                            for (int n2 = 1; n2 <= 9; n2++)
                            {
                                if(n1 == n2) continue;
                                for (int n3 = 1; n3 <= 9; n3++)
                                {
                                    if (n3 == n1||n3==n2) continue;
                                    for (int n4 = 1; n4 <= 9; n4++)
                                    {
                                        if (n4 == n3 ||n4==n2||n4==n1) continue;
                                        for (int n5 = 1; n5 <= 9; n5++)
                                        {
                                            if (n5 == n4 || n5 == n3 || n5 == n2 || n5 == n1) continue;
                                            //if(n5!=5) continue;
                                            for (int n6 = 1; n6 <= 9; n6++)
                                            {
                                                if (n6 == n5 || n6 == n4 || n6 == n3 || n6 == n2||n6==n1) continue;
                                                if(n2 % 2 ==0 || n6 % 2==0) continue;
                                                for (int n7 = 1; n7 <= 9; n7++)
                                                {
                                                    if (n7 == n6 || n7 == n5 || n7 == n4 || n7 == n3 || n7 == n2||n7==n1) continue;
                                                    int A = n1 * 100 + n4 * 10 + n7;int B = n4 * 100 + n5 * 10 + n6;
                                                    if(GCD(A,B)<=2) continue;
                                                    for (int n8 = 1; n8 <= 9; n8++)
                                                    {
                                                        if (n8 == n7 || n8 == n6 || n8 == n5 || n8 == n4 || n8 == n3 || n8 == n2||n8==n1) continue;
                                                        if(n4 % 2==1 || n8 % 2==1) continue;
                                                        for (int n9 = 1; n9 <= 9; n9++)
                                                        {
                                                            if (n9 == n8 || n9 == n7 || n9 == n6 || n9 == n5 || n9 == n4 || n9 == n3 || n9 == n2||n9==n1) continue;
                                                            int NN = n1 + n3 + n7 + n9;
                                                            if(!PrimeYesNo(NN)) continue;
                                                            counter++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Finish = System.DateTime.Now.TimeOfDay.TotalSeconds;
                        Console.WriteLine(counter + "組解");
                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                finally
                {
                    Console.WriteLine("計時 :" + Math.Round(Finish - Strart, 4) + "秒");
                    Console.ReadKey();
                }
            }
        }
        static bool PrimeYesNo(decimal X)
        {
            if (X <= 1) return false;
            else if (X == 2) return true;
            else if (X % 2 == 0) return false;
            else
            {
                //for (decimal i = 3; i < X; i = i + 2)
                for (decimal i = 3; i <= (decimal)Math.Pow((double)X, 1.0 / 2.0); i = i + 2)
                {
                    if (X % i == 0) return false;
                }
                return true;
            }                   
        }
        static decimal GCD(decimal A, decimal B)
        {
            if (B > A)
            {
                int temp =(int)B;
                B = A;
                A = temp;
            }

            while (A % B != 0)
            {
                decimal R = A % B;
                A = B;
                B = R;
            }

            return B;
        }
    }
}
