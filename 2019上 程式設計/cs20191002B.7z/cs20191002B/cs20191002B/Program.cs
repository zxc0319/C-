﻿using System;


namespace cs20191002B
{
    class Program
    {
        static void Main(string[] args)
        {
            while(true)
                try
                {
                    checked
                    {
                        //1.梯形面積:(上底 + 下底) * 高 / 2
                        Console.Write("Inputd 上底=? 下底=? 高=?");
                        string[] str = Console.ReadLine().Split(' ');
                        double X = double.Parse(str[0]);
                        double Y = double.Parse(str[1]);
                        double Z = double.Parse(str[2]);
                        Console.WriteLine("梯形面積 =" + Math.Round((X + Y) * Z * 0.5, 1));

                        //2.正方形面積:邊長* 邊長
                        Console.Write("Inputd 邊長=?");
                        string[] a = Console.ReadLine().Split(' ');
                        double A = double.Parse(str[0]);
                        Console.WriteLine("正方形面積 =" + Math.Round(X * Y, 1));

                        //3.圓面積
                        Console.Write("Inputd 半徑=?  ");
                        string[] b = Console.ReadLine().Split(' ');
                        double B = double.Parse(str[0]);
                        Console.WriteLine("圓面積 =" + Math.Round(Math.PI * X*X),1);
                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                finally
                {
                    Console.WriteLine("Hille! 資一乙");
                }
            
        }
    }
}
