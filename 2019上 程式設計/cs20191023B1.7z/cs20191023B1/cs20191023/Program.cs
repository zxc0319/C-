﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs20191023
{
    class Program
    {
        static void Main(string[] args)
        {while(true)
                try
                {
                    Console.WriteLine("\n**************************************************\n");
                    Console.WriteLine("BMI(Body Mass Index)\n資料來源: http://zh.wikipedia.org/wiki/身高體重指數 ");
                    Console.WriteLine("\n==================================================\n");
                    Console.Write("請輸入性別-女[Female](0/f/F)男[Male](1/m/M)？");
                    string FM = Console.ReadLine();
                    bool sex;
                    checked
                    {
                        //1.女生
                        if(FM=="0" || FM=="f" || FM == "F")
                        {
                            sex = false;
                            Console.WriteLine("性別: 女("+ sex +")");
                            Console.Write("請輸入腰圍(cm)?");
                            double Waist = double.Parse(Console.ReadLine());
                            Console.Write("請輸入身高(cm)?");
                            double Height = double.Parse(Console.ReadLine());
                            Console.Write("請輸入體重(Kg)?");
                            double Weight = double.Parse(Console.ReadLine());


                            double BMI = Weight / Math.Pow(Height / 100, 2);
                            Console.WriteLine("BMI(體質數[" + BMI + "])= " + Math.Round(BMI, 1));
                            BMI = Math.Round(BMI, 1);

                            //if (BMI<18.5) Console.WriteLine("體重過低!!");                           
                            //else if ( BMI > 23.9) Console.WriteLine("體重超重!!");
                            //else Console.WriteLine("體重正常!!");

                            //BMI
                            if (BMI < 18.5)
                            {
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                Console.WriteLine("體重過低!!");
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            else if (BMI >= 18.5 && BMI <= 23.9)
                            {
                                Console.WriteLine("體重正常!!");
                            }
                            else if (BMI >= 24 && BMI <= 27.9)
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("體重超重!!");
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            //else if (BMI >= 28d)
                            //{
                            //    Console.ForegroundColor = ConsoleColor.Yellow;
                            //    Console.WriteLine("肥胖!!");
                            //    Console.ForegroundColor = ConsoleColor.White;
                            //}
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("肥胖!!");
                                Console.ForegroundColor = ConsoleColor.White;
                            }

                            //腰圍
                            if (BMI < 18.5)
                            {
                                if (Waist < 80)
                                {
                                    Console.WriteLine("腰圍正常!!");
                                }
                                else if (Waist > 80 && Waist < 90)
                                {
                                    Console.WriteLine("腰圍正常!!");
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("腰圍危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                            else if (BMI >= 18.5 && BMI <= 23.9)
                            {
                                if (Waist <80)
                                {
                                    Console.WriteLine("腰圍正常!!");
                                }
                                else if (Waist >= 80&& Waist < 90)
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("腰圍危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                    Console.WriteLine("腰圍高危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                            else if (BMI >= 24 && BMI <= 27.9)
                            {
                                if (Waist < 80)
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("腰圍危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else if (Waist >= 80&& Waist < 90)
                                {
                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                    Console.WriteLine("腰圍高危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("腰圍極高危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                            else
                            {
                                if (Waist < 80)
                                {
                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                    Console.WriteLine("腰圍高危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else if (Waist > 80&& Waist < 95)
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("腰圍極高危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("腰圍極最危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                        }

                        //2.男生
                        else if (FM == "1" || FM == "m" || FM == "M")
                        {
                            sex = true;
                            Console.WriteLine("性別: 男(" + sex + ")");
                            Console.Write("請輸入腰圍(cm)?");
                            double Waist = double.Parse(Console.ReadLine());
                            Console.Write("請輸入身高(cm)?");
                            double Height = double.Parse(Console.ReadLine());
                            Console.Write("請輸入體重(Kg)?");
                            double Weight = double.Parse(Console.ReadLine());                         


                            double BMI = Weight / Math.Pow(Height / 100, 2);
                            Console.WriteLine("BMI(體質數["+BMI+ "])= "+Math.Round(BMI,1));
                            BMI = Math.Round(BMI, 1);

                            //if (BMI<18.5) Console.WriteLine("體重過低!!");                           
                            //else if ( BMI > 23.9) Console.WriteLine("體重超重!!");
                            //else Console.WriteLine("體重正常!!");

                            //BMI
                            if (BMI < 18.5)
                            {
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                Console.WriteLine("體重過低!!");
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            else if (BMI >= 18.5 && BMI <= 23.9)
                            {
                                Console.WriteLine("體重正常!!");
                            }
                            else if (BMI >= 24 && BMI <= 27.9)
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("體重超重!!");
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            //else if (BMI >= 28d)
                            //{
                            //    Console.ForegroundColor = ConsoleColor.Yellow;
                            //    Console.WriteLine("肥胖!!");
                            //    Console.ForegroundColor = ConsoleColor.White;
                            //}
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("肥胖!!");
                                Console.ForegroundColor = ConsoleColor.White;
                            }

                            //腰圍
                            if (BMI < 18.5) 
                            {
                                if (Waist < 85)
                                {
                                    Console.WriteLine("腰圍正常!!");
                                }
                                else if (Waist > 85 && Waist < 95)
                                {
                                    Console.WriteLine("腰圍正常!!");
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("腰圍危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }                          
                            }
                            else if (BMI >= 18.5 && BMI <= 23.9)
                            {
                                if (Waist < 85)
                                {
                                    Console.WriteLine("腰圍正常!!");
                                }
                                else if (Waist >= 85 && Waist < 95)
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("腰圍危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                    Console.WriteLine("腰圍高危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                            else if (BMI >= 24 && BMI <= 27.9)
                            {
                                if (Waist < 85)
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("腰圍危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else if (Waist >= 85 && Waist < 95)
                                {
                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                    Console.WriteLine("腰圍高危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("腰圍極高危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                            else 
                            {
                                if (Waist < 85)
                                {
                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                    Console.WriteLine("腰圍高危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else if (Waist > 85 && Waist < 95)
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("腰圍極高危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("腰圍極最危險!!");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("性別選擇錯誤！");
                        }                        

                    }
                }
                catch(Exception E)
                {
                    Console.WriteLine(E.ToString());                    
                }
                finally
                {
                    Console.WriteLine(".........Pause(Press any key to continue)");
                    Console.ReadKey();
                }


        }
    }
}
