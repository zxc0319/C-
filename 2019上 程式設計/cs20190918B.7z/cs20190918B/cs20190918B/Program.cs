﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs20190918B
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("拉拉拉巴巴巴");
            Console.WriteLine("巴巴巴拉拉拉");
            Console.WriteLine("哈哈哈哈哈哈");
            Console.Write("哭哭哭哭哭哭");

            Console.ReadKey();

        }
    }
}
