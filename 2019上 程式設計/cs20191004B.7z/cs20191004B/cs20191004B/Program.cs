﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs20191004B
{
    class Program
    {
        static void Main(string[] args)
        { 
            while(true)
            {
                try
                {
                    checked
                    {
                        //華氏=攝氏*(9/5)+32 ℉
                        //攝氏=(華氏-32)*5/9 ℃
                        Console.WriteLine("Input 溫度? <1>攝氏轉華氏<2>華氏轉攝氏<其他>結束");
                        string[] str =Console.ReadLine().Split(' ');
                        double degree = double.Parse(str[0]);
                        int which = int.Parse(str[1]);
                        double C, F;
                        //if (which == 1)
                        //{
                        //    C = degree;
                        //    F = C * (9.0 / 5.0) + 32;
                        //    Console.WriteLine("攝氏" + Math.Round(C, 1) + "℃" + "華氏" + Math.Round(F, 1) + "℉");
                        //}
                        //else if (which == 2)
                        //{
                        //    F = degree;
                        //    C = (F - 32) * 5.0 / 9.0;
                        //    Console.WriteLine("攝氏" + Math.Round(C, 1) + "℃" + "華氏" + Math.Round(F, 1) + "℉");
                        //}
                        //else
                        //{
                        //    return;
                        //}
                        switch (which)
                        {
                            case 1:
                                C = degree;
                                F = C * (9.0 / 5.0) + 32;
                                break;
                            case 2:
                                F = degree;
                                C = (F - 32) * 5.0 / 9.0;
                                break;
                            default:
                                return;   
                        }
                        Console.WriteLine("攝氏" + Math.Round(C, 1) + "℃" + "華氏" + Math.Round(F, 1) + "℉");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                finally
                {
                    Console.WriteLine("Hello 資一乙");
                }




            }
            
        }
    }
}
