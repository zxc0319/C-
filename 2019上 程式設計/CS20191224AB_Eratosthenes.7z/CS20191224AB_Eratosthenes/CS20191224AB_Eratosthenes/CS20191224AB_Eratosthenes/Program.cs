﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20191224AB_Eratosthenes
{
    class Program
    {
        static void Main(string[] args)
        {
            //Random RN = new Random();
            //RN.Next(0, 101);
            Eratoshenes PN = new Eratoshenes();
            PN.Create();
            while (true)
            {
                try
                {
                    checked
                    { 
                        Console.WriteLine("Prime Number？？(Between two Number)2147483646 2146480000");
                        string[] Line = Console.ReadLine().Split(' ');
                        if (Line[0] == "") break;
                        int X = int.Parse(Line[0]);
                        int Y = int.Parse(Line[1]);
                        int temp;
                        if (X > Y) { temp = X; X = Y; Y = temp; }

                        //Flowchart of prime number：http://www.rff.com/prime-numbers.htm
                        //Eratosthenes：https://en.wikipedia.org/wiki/Eratosthenes
                        //埃拉托斯特尼篩法：https://zh.wikipedia.org/wiki/埃拉托斯特尼篩法                        
                        //質數列表：https://zh.wikipedia.org/wiki/質數列表                        
                        //前1000個質數：https://miniwebtool.com/zh-tw/first-n-prime-numbers/?number=1000

                        uint no = 0;   //number of prime number                        
                        string result = null;
                        double Start = DateTime.Now.TimeOfDay.TotalSeconds;
                        for (int i = X; i <= Y; i++)  //i <= 2147483646
                        {
                            //if (PrimeYesNo(i))
                            if(PN.Test(i))
                            {
                                no++;
                                //Console.WriteLine("P" + no + "= " + i);
                                result += "P[" + no + "]= " + i + "\n";
                            }
                        }
                        Console.WriteLine(result);
                        double Finish = DateTime.Now.TimeOfDay.TotalSeconds;
                        Console.WriteLine("\n共計 " + no + " 個質數：" + Math.Round(Finish - Start, 3) + "秒");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());                    
                }
                finally 
                {
                    //Console.WriteLine("Press any key to Exit");
                }
            }
        }
        static bool PrimeYesNo(int N)
        {
            if (N <= 1) return false;
            else if (N == 2) return true;
            else if (N % 2 == 0) return false;
            else
            {
                for (int i = 3; N >= (long)i * (long)i; i += 2)                     // 18秒
                                                                                    //for (int i = 3; N >= i*i; i += 2)    // i*i overflow used int type; checked{}
                    /*for (int i = 3; i <= Math.Sqrt(N) + 1; i += 2)*/                      // 20秒
                    /*for (int i = 3; i <= (int)Math.Pow((double)N,1.0/2.0)+1; i += 2)*/      // 77秒
                {
                    if (N % i == 0) return false;
                }
                return true;                           
            }
        }
    }
    class Eratoshenes
    {
        public int[] PrimeNo = new int[100001];     //[0~100000]

        public void Create()
        {
            Console.WriteLine("\n\n" + System.DateTime.Now);
            PrimeNo[1] = 2; PrimeNo[2] = 3; PrimeNo[3] = 5; PrimeNo[4] = 7;
            Console.WriteLine("\n\n" + System.DateTime.Now);
            int NN = 11;
            int NP;
            for (int n = 5; n <= 100000; n++)
            {
                NP = 1;
                while(Math.Sqrt(NN)+1>PrimeNo[NP])
                {
                    if (NN % PrimeNo[NP] == 0)
                    {
                        NN++;
                        NP = 1;
                    }
                    else NP++;
                }
                PrimeNo[n]=NN;
                NN++;
            }
        }

        public bool Test(int N)
        {
            return true;
        }

    }
}
