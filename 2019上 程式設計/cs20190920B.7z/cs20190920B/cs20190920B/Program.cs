﻿using System;


namespace cs20190920B
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello! 108資一乙");
            Console.WriteLine("Hello! 108IM1B");
            Console.WriteLine("Hello! 108資一甲");
            Console.WriteLine("Hello! 108IM1A");
            Console.WriteLine("AB" + "CD");
            Console.WriteLine("11+9=" + (11 + 9));
            Console.WriteLine("11-9=" + (11 - 9));
            Console.WriteLine("11*9=" + (11 * 9));
            Console.WriteLine("11/9=" + (11.0 / 9.0));
            Console.WriteLine("11*9=" + (11 * 9));
            Console.WriteLine("11%9=" + (11 % 9));
            Console.WriteLine("3^4=" + Math.Pow(3,4));
            Console.WriteLine("3^4*9=" + (Math.Pow(3, 4)*9));
            Console.WriteLine("144^(1/2)=" + Math.Pow(144,1 / 2.0));
            Console.WriteLine("125^(1/3)=" + Math.Pow(125,1 / 3.0));
            Console.WriteLine("123456*654321=" + ((long)123456 * (long)654321));
            Console.ReadKey();
        }
    }
}
