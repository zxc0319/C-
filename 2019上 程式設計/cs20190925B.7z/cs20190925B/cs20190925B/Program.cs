﻿using System;


namespace cs20190925B
{
    class Program
    {
        static void Main(string[] args)
        {
            //2.Variables(變數)
            //f(x,y)=x+y
            //f(2,3)=5
            //f(9,1)=10
            //2a.Defining Variables(Declarartion,宣告資料型態)
            //int X;
            //int Y;
            //int X, Y;
            //2b.Initializing Variables
            //X = 2;
            //Y = 3;
            //Console.WriteLine("X+Y=" + (X + Y));
            //Console.WriteLine("X*Y=" + (X * Y));
            //X++;
            //Y++;
            //Console.WriteLine("X+Y=" + (X + Y));
            //Console.WriteLine("X*Y=" + (X * Y));
            //X = 13;
            //Y = 3;
            //X--;
            //Y--;
            //Console.WriteLine("X+Y=" + (X + Y));
            //long A,B;
            //A = 123456789012345678;
            //B = 987654321098765432;
            long A = 123456789012345678;
            long B = 987654321098765432;
            Console.WriteLine("A+B=" + (A + B));
            Console.WriteLine("A*B=" + (A * B));  //?????Overflow(溢位)

            //Console.WriteLine("****+1" + (2147483647 + 1));
            Console.WriteLine("2147483647+1" + ((long)2147483647 + 1));
            
            int C = 2147483647;
            int D = 2;
            Console.WriteLine("C+D=" + (C + D));
            Console.ReadKey();
            //Console.WriteLine("C+D=" + checked(C + D));
            //Overflow(溢位)Underflow
            checked 
            {
                Console.WriteLine("C+D=" + (C + D));
                Console.WriteLine("A*B=" + (A * B));
            }





            //1.Constant(常數) String(字串)
            //Console.WriteLine("Hello! 108資一乙");
            //Console.WriteLine("Hello! 108IM1B");
            //Console.WriteLine("Hello! 108資一甲");
            //Console.WriteLine("Hello! 108IM1A");
            //Console.WriteLine("AB" + "CD");
            //Console.WriteLine("11+9=" + (11 + 9));
            //Console.WriteLine("11-9=" + (11 - 9));
            //Console.WriteLine("11*9=" + (11 * 9));
            //Console.WriteLine("11/9=" + (11.0 / 9.0));
            //Console.WriteLine("11*9=" + (11 * 9));
            //Console.WriteLine("11%9=" + (11 % 9));
            //Console.WriteLine("3^4=" + Math.Pow(3,4));
            //Console.WriteLine("3^4*9=" + (Math.Pow(3, 4)*9));
            //Console.WriteLine("144^(1/2)=" + Math.Pow(144,1 / 2.0));
            //Console.WriteLine("125^(1/3)=" + Math.Pow(125,1 / 3.0));
            //Console.WriteLine("123456*654321=" + ((long)123456 * (long)654321));
            Console.ReadKey();
        }
    }
}
