﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20191211B
{
    class Program
    {
        static void Main(string[] args)
        {
            Random RN = new Random();
            while (true)
            {
                try
                {
                    Console.Write("INPUT number of Student？Max. Length of Last Name？Sorting by Score/Name[S(Descending)/N(Ascending)/SN]？");
                    string[] line = Console.ReadLine().Split(' ');
                    int number = int.Parse(line[0]);
                    int NameLength = int.Parse(line[1]);

                    string Name;
                    int BCC, CSharp, DS, Total;
                    int[] Scores = new int[1000];
                    string[] ST = new string[1000];
                    for (int i = 1; i <= number; i++)
                    {
                        Name = ((char)RN.Next(65, 91)).ToString();
                        for(int j=1;j<=RN.Next(1,NameLength-1); j++)
                        {
                            Name += (char)RN.Next(97, 123);
                        }

                        BCC = RN.Next(0, 101);
                        CSharp = RN.Next(0, 101);
                        DS = RN.Next(0, 101);
                        Total = BCC + CSharp + DS;

                        Scores[i - 1] = Total;
                        ST[i - 1] = i + "." + Name + " : " + BCC + " + " + CSharp + " + " + DS + " = ";

                        Console.WriteLine(i+"."+Name+" : "+BCC+" + "+CSharp+" + "+DS+" = "+Total+"\n");
                    }
                    Console.WriteLine("======================================================");
                    for(int k = 0; k <= number - 1; k++)Console.WriteLine(ST[k] + Scores[k]);
                    

                    checked
                    {
                        
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    
                }

            }

            
        }
    }
}
