﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20191113B
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("\n\n" + DateTime.Now);
                    Console.Write("[A]Factorial？？  [B]Fibonacci？？  [C]Prime Number？  [D]GCD[LCM] = (Input Number：？？)");
                    string[] line = Console.ReadLine().Split(' ');
                    if (line[0] == "") break;
                    string which = line[0];
                    checked
                    {
                        switch (which)
                        {                            
                            case "A":
                                {
                                    int A1 = int.Parse(line[1]);
                                    int A2 = int.Parse(line[2]);
                                    if (A1 > A2)
                                    {
                                        int temp = A2;
                                        A2 = A1;
                                        A1 = temp;
                                    }
                                    for (int n = A1; n <= A2; n++)
                                    {
                                        if (n < 0)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine(n + "!= N!之N值須 >= 0");
                                            Console.ResetColor();
                                        }
                                        else Console.WriteLine(n + "!=" + Factorial(n));
                                    }
                                    {
                                        //int N = int.Parse(line[1]);                                
                                        //int M = 1;
                                        ////int F = 1;
                                        //decimal F = 1;
                                        //if (N < 0)
                                        //{
                                        //    Console.WriteLine("N!輸入直需>=0");
                                        //    break;
                                        //}
                                        //else if (N == 0)
                                        //{
                                        //    Console.WriteLine("定義0!=1");
                                        //    break;
                                        //}

                                        ////1.while()
                                        ////while (!(M==N))
                                        ////while(M!=N)
                                        ////{                                    
                                        ////    M = M + 1;
                                        ////    F = F * M;
                                        ////}
                                        ////2.for loop
                                        //for(int i=1;i<=N ;i++ )
                                        //{
                                        //    F = F * i;
                                        //}
                                        //Console.WriteLine(N + "!=" + F);
                                    }
                                }
                                break;
                            case "B":
                                {
                                    int B1 = int.Parse(line[1]);
                                    int B2 = int.Parse(line[2]);
                                    if (B1 > B2)
                                    {
                                        int temp = B2;
                                        B2 = B1;
                                        B1 = temp;
                                    }
                                    for (int n = B1; n <= B2; n++)
                                    {
                                        if (n < 0)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine("Fib(" + n + ")=" + "Fib(n)之n >= 0");
                                            Console.ResetColor();
                                        }
                                        else
                                        {
                                            Console.Write("Fib(" + n + ")=" + Fibonacci(n));
                                            if (Fibonacci(n) % 2 == 0) Console.WriteLine("[偶]");
                                            else Console.WriteLine("(奇)");
                                        }
                                    }
                                    {
                                        //decimal F0 = 0;
                                        //decimal F1 = 1;
                                        //Console.WriteLine("\nFib(0)=0" + "\n" + "fib(1)=1");
                                        //int f = 2;
                                        //decimal Fn = 0;
                                        //while(f<= int.Parse(line[1]))
                                        //{
                                        //    Fn = F0 + F1;
                                        //    F0 = F1;
                                        //    F1 = Fn;                               
                                        //    Console.WriteLine("Fib(" + f + ")=" + Fn);
                                        //    f++;
                                        //}
                                    }
                                }
                                break;

                            case "C":
                                decimal nth = 0;
                                decimal NN = 0;
                                decimal Number = int.Parse(line[1]);
                                double Begin = System.DateTime.Now.TimeOfDay.TotalSeconds;
                                string result = null;
                                while (nth < Number)
                                {
                                    if (PrimeYesNo(NN))
                                    {
                                        nth++;
                                        //Console.WriteLine("P" + nth + "= "+NN);
                                        result += "P" + nth + "= " + NN + "\n";
                                    }
                                    NN++;
                                }
                                Console.WriteLine(result);
                                double Finish = DateTime.Now.TimeOfDay.TotalSeconds;
                                Console.WriteLine("計算" + Number + " 個質數計:" + Math.Round(Finish - Begin, 3)+"秒");
                                

                                    break;

                            case "D":
                                {
                                    decimal X = decimal.Parse(line[1]);
                                    decimal Y = decimal.Parse(line[2]);
                                    Console.WriteLine("GCD(" + X + "," + Y + ") =" + GCD(X, Y));
                                    Console.WriteLine("LCM(" + X + "," + Y + ") =" + LCM(X, Y));
                                    break;
                                }
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                finally
                {
                    Console.WriteLine(".......Pause(Press any key to continue)");
                    Console.ReadKey();
                }
            }
        }
        static decimal Factorial(int X)
        {
            decimal F;
            if (X == 0) F = 1;
            else
            {
                F = 1;
                for (int M = 1; M <= X; M++)
                {
                    F = F * M;
                }
            }
            return F;
        }
        static decimal Fibonacci(int X)
        {
            if (X == 1) return 1;
            decimal F0 = 0;
            decimal F1 = 1;            
            int f = 2;
            decimal Fn = 0;
            while (f <= X)
            {
                Fn = F0 + F1;
                F0 = F1;
                F1 = Fn;                
                f++;
            }
            return Fn;
        }
        static decimal GCD(decimal A , decimal B)
        {
                         
            while(A%B != 0)
            {
                decimal R = A % B;
                A = B;
                B = R;
            }

            return B;
        }
        static decimal LCM(decimal A, decimal B)
        {            
            return Math.Abs(A*B)/GCD(A,B);
        }

        static bool PrimeYesNo (decimal X)
        {
            if (X <= 1) return false;
            else if (X == 2) return true;
            else if (X % 2 == 0) return false;
            else
            {
                //for (decimal i = 3; i < X; i = i + 2)
                for (decimal i = 3; i <= (decimal)Math.Pow((double)X, 1.0 / 2.0); i = i + 2)
                {
                    if (X % i == 0) return false;
                }
                return true;
            }

            //1.Definition
            //if (X<=1) return false;
            //else
            //{
            //   for(decimal i=2; i < X; i++)
            //    {
            //        if (X % i == 0) return false;
            //    }
            //    return true;
            //}                        


        }


    }
}
